﻿namespace WindowsFormsApp2
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.роботаЗДанимиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.категоріїToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.постачальникиПоставкиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.запчастиниToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.технікаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.продажToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.послугиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оформленняПослугиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.списокПрацівниківToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.звітиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.bindingNavigator1 = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.postachDataGridView = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.postavkiDataGridView = new System.Windows.Forms.DataGridView();
            this.bindingNavigator2 = new System.Windows.Forms.BindingNavigator(this.components);
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripTextBox1 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton6 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton7 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton8 = new System.Windows.Forms.ToolStripButton();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.zapchastunuDataGridView = new System.Windows.Forms.DataGridView();
            this.bindingNavigator3 = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem1 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem1 = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem1 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem1 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem1 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem1 = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem1 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem1 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton9 = new System.Windows.Forms.ToolStripButton();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.bindingNavigator4 = new System.Windows.Forms.BindingNavigator(this.components);
            this.toolStripButton17 = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel3 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButton18 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton19 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton20 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripTextBox3 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton21 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton22 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton23 = new System.Windows.Forms.ToolStripButton();
            this.type_ZapDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.toolStripButton12 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton13 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripTextBox2 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripLabel2 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton14 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton15 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton10 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton11 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton16 = new System.Windows.Forms.ToolStripButton();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.bindingNavigator5 = new System.Windows.Forms.BindingNavigator(this.components);
            this.toolStripButton24 = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel4 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButton25 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton26 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton27 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator10 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripTextBox4 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator11 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton28 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton29 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator12 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton30 = new System.Windows.Forms.ToolStripButton();
            this.prodaj_ZapDataGridView = new System.Windows.Forms.DataGridView();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.bindingNavigator6 = new System.Windows.Forms.BindingNavigator(this.components);
            this.toolStripButton31 = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel5 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButton32 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton33 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton34 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator13 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripTextBox5 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator14 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton35 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton36 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator15 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton37 = new System.Windows.Forms.ToolStripButton();
            this.prodaj_TehnDataGridView = new System.Windows.Forms.DataGridView();
            this.Date_Z = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.comments = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabControl4 = new System.Windows.Forms.TabControl();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.bindingNavigator7 = new System.Windows.Forms.BindingNavigator(this.components);
            this.toolStripButton38 = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel6 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButton39 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton40 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton41 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator16 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripTextBox6 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator17 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton42 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton43 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator18 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton44 = new System.Windows.Forms.ToolStripButton();
            this.zdiysn_PoslugiDataGridView = new System.Windows.Forms.DataGridView();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.poslugaDataGridView = new System.Windows.Forms.DataGridView();
            this.bindingNavigator8 = new System.Windows.Forms.BindingNavigator(this.components);
            this.toolStripButton45 = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel7 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButton46 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton47 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton48 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator19 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripTextBox7 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator20 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton49 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton50 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator21 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton51 = new System.Windows.Forms.ToolStripButton();
            this.tabControl5 = new System.Windows.Forms.TabControl();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.bindingNavigator9 = new System.Windows.Forms.BindingNavigator(this.components);
            this.toolStripButton52 = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel8 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButton53 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton54 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton55 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator22 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripTextBox8 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator23 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton56 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton57 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator24 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton58 = new System.Windows.Forms.ToolStripButton();
            this.tehnikaDataGridView = new System.Windows.Forms.DataGridView();
            this.tabPage11 = new System.Windows.Forms.TabPage();
            this.bindingNavigator11 = new System.Windows.Forms.BindingNavigator(this.components);
            this.toolStripButton66 = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel10 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButton67 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton68 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton69 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator28 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripTextBox10 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator29 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton70 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton71 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator30 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton72 = new System.Windows.Forms.ToolStripButton();
            this.stanDataGridView = new System.Windows.Forms.DataGridView();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.bindingNavigator10 = new System.Windows.Forms.BindingNavigator(this.components);
            this.toolStripButton59 = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel9 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButton60 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton61 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton62 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator25 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripTextBox9 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator26 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton63 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton64 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator27 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton65 = new System.Windows.Forms.ToolStripButton();
            this.tipDataGridView = new System.Windows.Forms.DataGridView();
            this.tabPage12 = new System.Windows.Forms.TabPage();
            this.bindingNavigator12 = new System.Windows.Forms.BindingNavigator(this.components);
            this.toolStripButton73 = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel11 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButton74 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton75 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton76 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator31 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripTextBox11 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator32 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton77 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton78 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator33 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton79 = new System.Windows.Forms.ToolStripButton();
            this.tabControl6 = new System.Windows.Forms.TabControl();
            this.tabControl7 = new System.Windows.Forms.TabControl();
            this.tabPage13 = new System.Windows.Forms.TabPage();
            this.bindingNavigator13 = new System.Windows.Forms.BindingNavigator(this.components);
            this.toolStripButton80 = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel12 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButton81 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton82 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton83 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator34 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripTextBox12 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator35 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton84 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton85 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator36 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton86 = new System.Windows.Forms.ToolStripButton();
            this.pracivnukuDataGridView = new System.Windows.Forms.DataGridView();
            this.servisniy_CentrDataSet = new WindowsFormsApp2.Servisniy_CentrDataSet();
            this.tehnikaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.poslugaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.pracivnukuBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewTextBoxColumn35 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn36 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn37 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn38 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn39 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn40 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.tipBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewTextBoxColumn41 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.stanBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewTextBoxColumn44 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn45 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn42 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn43 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.postachBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.typeZapBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.postavkiBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.iDTypeZapDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nazvanieDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.zapchastunuBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.zdiysn_PoslugiBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewTextBoxColumn26 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn29 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn30 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn31 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn32 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn33 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn34 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prodaj_ZapBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn22 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.prodaj_TehnBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewTextBoxColumn23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn25 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn55 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn56 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn57 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn58 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn59 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.postachBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.tableAdapterManager = new WindowsFormsApp2.Servisniy_CentrDataSetTableAdapters.TableAdapterManager();
            this.zapchastunuTableAdapter = new WindowsFormsApp2.Servisniy_CentrDataSetTableAdapters.ZapchastunuTableAdapter();
            this.servisniy_CentrDataSet1 = new WindowsFormsApp2.Servisniy_CentrDataSet();
            this.type_ZapTableAdapter = new WindowsFormsApp2.Servisniy_CentrDataSetTableAdapters.Type_ZapTableAdapter();
            this.postachTableAdapter = new WindowsFormsApp2.Servisniy_CentrDataSetTableAdapters.PostachTableAdapter();
            this.postavkiTableAdapter = new WindowsFormsApp2.Servisniy_CentrDataSetTableAdapters.PostavkiTableAdapter();
            this.prodaj_ZapTableAdapter = new WindowsFormsApp2.Servisniy_CentrDataSetTableAdapters.Prodaj_ZapTableAdapter();
            this.prodaj_TehnTableAdapter = new WindowsFormsApp2.Servisniy_CentrDataSetTableAdapters.Prodaj_TehnTableAdapter();
            this.zdiysn_PoslugiTableAdapter = new WindowsFormsApp2.Servisniy_CentrDataSetTableAdapters.Zdiysn_PoslugiTableAdapter();
            this.poslugaTableAdapter = new WindowsFormsApp2.Servisniy_CentrDataSetTableAdapters.PoslugaTableAdapter();
            this.tehnikaTableAdapter = new WindowsFormsApp2.Servisniy_CentrDataSetTableAdapters.TehnikaTableAdapter();
            this.tipTableAdapter = new WindowsFormsApp2.Servisniy_CentrDataSetTableAdapters.TipTableAdapter();
            this.stanTableAdapter = new WindowsFormsApp2.Servisniy_CentrDataSetTableAdapters.StanTableAdapter();
            this.pracivnukuTableAdapter = new WindowsFormsApp2.Servisniy_CentrDataSetTableAdapters.PracivnukuTableAdapter();
            this.akt_peredachi_v_remontBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.akt_peredachi_v_remontTableAdapter = new WindowsFormsApp2.Servisniy_CentrDataSetTableAdapters.Akt_peredachi_v_remontTableAdapter();
            this.akt_peredachi_v_remontDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn46 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn47 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn48 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn49 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn50 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn51 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn52 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn53 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn54 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.menuStrip1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator1)).BeginInit();
            this.bindingNavigator1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.postachDataGridView)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.postavkiDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator2)).BeginInit();
            this.bindingNavigator2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.zapchastunuDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator3)).BeginInit();
            this.bindingNavigator3.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator4)).BeginInit();
            this.bindingNavigator4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.type_ZapDataGridView)).BeginInit();
            this.tabControl3.SuspendLayout();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator5)).BeginInit();
            this.bindingNavigator5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.prodaj_ZapDataGridView)).BeginInit();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator6)).BeginInit();
            this.bindingNavigator6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.prodaj_TehnDataGridView)).BeginInit();
            this.tabControl4.SuspendLayout();
            this.tabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator7)).BeginInit();
            this.bindingNavigator7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.zdiysn_PoslugiDataGridView)).BeginInit();
            this.tabPage8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.poslugaDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator8)).BeginInit();
            this.bindingNavigator8.SuspendLayout();
            this.tabControl5.SuspendLayout();
            this.tabPage9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator9)).BeginInit();
            this.bindingNavigator9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tehnikaDataGridView)).BeginInit();
            this.tabPage11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator11)).BeginInit();
            this.bindingNavigator11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stanDataGridView)).BeginInit();
            this.tabPage10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator10)).BeginInit();
            this.bindingNavigator10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tipDataGridView)).BeginInit();
            this.tabPage12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator12)).BeginInit();
            this.bindingNavigator12.SuspendLayout();
            this.tabControl6.SuspendLayout();
            this.tabControl7.SuspendLayout();
            this.tabPage13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator13)).BeginInit();
            this.bindingNavigator13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pracivnukuDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.servisniy_CentrDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tehnikaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.poslugaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pracivnukuBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tipBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stanBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.postachBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.typeZapBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.postavkiBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zapchastunuBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zdiysn_PoslugiBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prodaj_ZapBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prodaj_TehnBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.postachBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.servisniy_CentrDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.akt_peredachi_v_remontBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.akt_peredachi_v_remontDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.роботаЗДанимиToolStripMenuItem,
            this.звітиToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1264, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.выходToolStripMenuItem});
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.файлToolStripMenuItem.Text = "Файл";
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(110, 22);
            this.выходToolStripMenuItem.Text = "выход ";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.выходToolStripMenuItem_Click);
            // 
            // роботаЗДанимиToolStripMenuItem
            // 
            this.роботаЗДанимиToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.категоріїToolStripMenuItem});
            this.роботаЗДанимиToolStripMenuItem.Name = "роботаЗДанимиToolStripMenuItem";
            this.роботаЗДанимиToolStripMenuItem.Size = new System.Drawing.Size(111, 20);
            this.роботаЗДанимиToolStripMenuItem.Text = "Робота з даними";
            // 
            // категоріїToolStripMenuItem
            // 
            this.категоріїToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.постачальникиПоставкиToolStripMenuItem,
            this.запчастиниToolStripMenuItem,
            this.технікаToolStripMenuItem,
            this.продажToolStripMenuItem,
            this.послугиToolStripMenuItem,
            this.оформленняПослугиToolStripMenuItem,
            this.списокПрацівниківToolStripMenuItem});
            this.категоріїToolStripMenuItem.Name = "категоріїToolStripMenuItem";
            this.категоріїToolStripMenuItem.Size = new System.Drawing.Size(123, 22);
            this.категоріїToolStripMenuItem.Text = "Категорії";
            // 
            // постачальникиПоставкиToolStripMenuItem
            // 
            this.постачальникиПоставкиToolStripMenuItem.Name = "постачальникиПоставкиToolStripMenuItem";
            this.постачальникиПоставкиToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.постачальникиПоставкиToolStripMenuItem.Text = "Постачальники, поставки";
            this.постачальникиПоставкиToolStripMenuItem.Click += new System.EventHandler(this.постачальникиПоставкиToolStripMenuItem_Click);
            // 
            // запчастиниToolStripMenuItem
            // 
            this.запчастиниToolStripMenuItem.Name = "запчастиниToolStripMenuItem";
            this.запчастиниToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.запчастиниToolStripMenuItem.Text = "Запчастини";
            this.запчастиниToolStripMenuItem.Click += new System.EventHandler(this.запчастиниToolStripMenuItem_Click);
            // 
            // технікаToolStripMenuItem
            // 
            this.технікаToolStripMenuItem.Name = "технікаToolStripMenuItem";
            this.технікаToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.технікаToolStripMenuItem.Text = "Техніка";
            this.технікаToolStripMenuItem.Click += new System.EventHandler(this.технікаToolStripMenuItem_Click);
            // 
            // продажToolStripMenuItem
            // 
            this.продажToolStripMenuItem.Name = "продажToolStripMenuItem";
            this.продажToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.продажToolStripMenuItem.Text = "Продаж";
            this.продажToolStripMenuItem.Click += new System.EventHandler(this.продажToolStripMenuItem_Click);
            // 
            // послугиToolStripMenuItem
            // 
            this.послугиToolStripMenuItem.Name = "послугиToolStripMenuItem";
            this.послугиToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.послугиToolStripMenuItem.Text = "Послуги";
            this.послугиToolStripMenuItem.Click += new System.EventHandler(this.послугиToolStripMenuItem_Click);
            // 
            // оформленняПослугиToolStripMenuItem
            // 
            this.оформленняПослугиToolStripMenuItem.Name = "оформленняПослугиToolStripMenuItem";
            this.оформленняПослугиToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.оформленняПослугиToolStripMenuItem.Text = "Оформлення послуги";
            this.оформленняПослугиToolStripMenuItem.Click += new System.EventHandler(this.оформленняПослугиToolStripMenuItem_Click);
            // 
            // списокПрацівниківToolStripMenuItem
            // 
            this.списокПрацівниківToolStripMenuItem.Name = "списокПрацівниківToolStripMenuItem";
            this.списокПрацівниківToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.списокПрацівниківToolStripMenuItem.Text = "Список працівників";
            this.списокПрацівниківToolStripMenuItem.Click += new System.EventHandler(this.списокПрацівниківToolStripMenuItem_Click);
            // 
            // звітиToolStripMenuItem
            // 
            this.звітиToolStripMenuItem.Name = "звітиToolStripMenuItem";
            this.звітиToolStripMenuItem.Size = new System.Drawing.Size(47, 20);
            this.звітиToolStripMenuItem.Text = "Звіти";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(2, 27);
            this.tabControl1.MaximumSize = new System.Drawing.Size(1680, 1050);
            this.tabControl1.MinimumSize = new System.Drawing.Size(800, 600);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1062, 600);
            this.tabControl1.TabIndex = 1;
            this.tabControl1.Visible = false;
            // 
            // tabPage1
            // 
            this.tabPage1.AutoScroll = true;
            this.tabPage1.BackColor = System.Drawing.Color.Transparent;
            this.tabPage1.Controls.Add(this.bindingNavigator1);
            this.tabPage1.Controls.Add(this.postachDataGridView);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1054, 574);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Постачальник";
            // 
            // bindingNavigator1
            // 
            this.bindingNavigator1.AddNewItem = this.bindingNavigatorAddNewItem;
            this.bindingNavigator1.BindingSource = this.postachBindingSource;
            this.bindingNavigator1.CountItem = this.bindingNavigatorCountItem;
            this.bindingNavigator1.DeleteItem = this.bindingNavigatorDeleteItem;
            this.bindingNavigator1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.toolStripButton1});
            this.bindingNavigator1.Location = new System.Drawing.Point(3, 3);
            this.bindingNavigator1.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.bindingNavigator1.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.bindingNavigator1.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.bindingNavigator1.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.bindingNavigator1.Name = "bindingNavigator1";
            this.bindingNavigator1.PositionItem = this.bindingNavigatorPositionItem;
            this.bindingNavigator1.Size = new System.Drawing.Size(1048, 25);
            this.bindingNavigator1.TabIndex = 2;
            this.bindingNavigator1.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Добавить";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem.Text = "для {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Удалить";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(75, 22);
            this.toolStripButton1.Text = "Оновити";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // postachDataGridView
            // 
            this.postachDataGridView.AutoGenerateColumns = false;
            this.postachDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.postachDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6});
            this.postachDataGridView.DataSource = this.postachBindingSource;
            this.postachDataGridView.Location = new System.Drawing.Point(4, 31);
            this.postachDataGridView.Name = "postachDataGridView";
            this.postachDataGridView.Size = new System.Drawing.Size(896, 394);
            this.postachDataGridView.TabIndex = 2;
            // 
            // tabPage2
            // 
            this.tabPage2.AutoScroll = true;
            this.tabPage2.Controls.Add(this.postavkiDataGridView);
            this.tabPage2.Controls.Add(this.bindingNavigator2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1054, 574);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Поставки";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // postavkiDataGridView
            // 
            this.postavkiDataGridView.AutoGenerateColumns = false;
            this.postavkiDataGridView.BackgroundColor = System.Drawing.SystemColors.ActiveBorder;
            this.postavkiDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.postavkiDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11});
            this.postavkiDataGridView.DataSource = this.postavkiBindingSource;
            this.postavkiDataGridView.Location = new System.Drawing.Point(2, 31);
            this.postavkiDataGridView.Name = "postavkiDataGridView";
            this.postavkiDataGridView.Size = new System.Drawing.Size(826, 355);
            this.postavkiDataGridView.TabIndex = 3;
            // 
            // bindingNavigator2
            // 
            this.bindingNavigator2.AddNewItem = this.toolStripButton2;
            this.bindingNavigator2.BindingSource = this.postavkiBindingSource;
            this.bindingNavigator2.CountItem = this.toolStripLabel1;
            this.bindingNavigator2.DeleteItem = this.toolStripButton3;
            this.bindingNavigator2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton4,
            this.toolStripButton5,
            this.toolStripSeparator1,
            this.toolStripTextBox1,
            this.toolStripLabel1,
            this.toolStripSeparator2,
            this.toolStripButton6,
            this.toolStripButton7,
            this.toolStripSeparator3,
            this.toolStripButton2,
            this.toolStripButton3,
            this.toolStripButton8});
            this.bindingNavigator2.Location = new System.Drawing.Point(3, 3);
            this.bindingNavigator2.MoveFirstItem = this.toolStripButton4;
            this.bindingNavigator2.MoveLastItem = this.toolStripButton7;
            this.bindingNavigator2.MoveNextItem = this.toolStripButton6;
            this.bindingNavigator2.MovePreviousItem = this.toolStripButton5;
            this.bindingNavigator2.Name = "bindingNavigator2";
            this.bindingNavigator2.PositionItem = this.toolStripTextBox1;
            this.bindingNavigator2.Size = new System.Drawing.Size(1048, 25);
            this.bindingNavigator2.TabIndex = 3;
            this.bindingNavigator2.Text = "bindingNavigator2";
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.RightToLeftAutoMirrorImage = true;
            this.toolStripButton2.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton2.Text = "Добавить";
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(43, 22);
            this.toolStripLabel1.Text = "для {0}";
            this.toolStripLabel1.ToolTipText = "Общее число элементов";
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.RightToLeftAutoMirrorImage = true;
            this.toolStripButton3.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton3.Text = "Удалить";
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.RightToLeftAutoMirrorImage = true;
            this.toolStripButton4.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton4.Text = "Переместить в начало";
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton5.Image")));
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.RightToLeftAutoMirrorImage = true;
            this.toolStripButton5.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton5.Text = "Переместить назад";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripTextBox1
            // 
            this.toolStripTextBox1.AccessibleName = "Положение";
            this.toolStripTextBox1.AutoSize = false;
            this.toolStripTextBox1.Name = "toolStripTextBox1";
            this.toolStripTextBox1.Size = new System.Drawing.Size(50, 23);
            this.toolStripTextBox1.Text = "0";
            this.toolStripTextBox1.ToolTipText = "Текущее положение";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton6
            // 
            this.toolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton6.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton6.Image")));
            this.toolStripButton6.Name = "toolStripButton6";
            this.toolStripButton6.RightToLeftAutoMirrorImage = true;
            this.toolStripButton6.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton6.Text = "Переместить вперед";
            // 
            // toolStripButton7
            // 
            this.toolStripButton7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton7.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton7.Image")));
            this.toolStripButton7.Name = "toolStripButton7";
            this.toolStripButton7.RightToLeftAutoMirrorImage = true;
            this.toolStripButton7.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton7.Text = "Переместить в конец";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton8
            // 
            this.toolStripButton8.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton8.Image")));
            this.toolStripButton8.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton8.Name = "toolStripButton8";
            this.toolStripButton8.Size = new System.Drawing.Size(75, 22);
            this.toolStripButton8.Text = "Оновити";
            this.toolStripButton8.Click += new System.EventHandler(this.toolStripButton8_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.White;
            this.tabPage3.Controls.Add(this.zapchastunuDataGridView);
            this.tabPage3.Controls.Add(this.bindingNavigator3);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1056, 574);
            this.tabPage3.TabIndex = 0;
            this.tabPage3.Text = "Запчастини";
            // 
            // zapchastunuDataGridView
            // 
            this.zapchastunuDataGridView.AutoGenerateColumns = false;
            this.zapchastunuDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.zapchastunuDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewCheckBoxColumn1,
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn16});
            this.zapchastunuDataGridView.DataSource = this.zapchastunuBindingSource;
            this.zapchastunuDataGridView.Location = new System.Drawing.Point(7, 31);
            this.zapchastunuDataGridView.Name = "zapchastunuDataGridView";
            this.zapchastunuDataGridView.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.zapchastunuDataGridView.Size = new System.Drawing.Size(747, 220);
            this.zapchastunuDataGridView.TabIndex = 0;
            // 
            // bindingNavigator3
            // 
            this.bindingNavigator3.AddNewItem = this.bindingNavigatorAddNewItem1;
            this.bindingNavigator3.BindingSource = this.zapchastunuBindingSource;
            this.bindingNavigator3.CountItem = this.bindingNavigatorCountItem1;
            this.bindingNavigator3.DeleteItem = this.bindingNavigatorDeleteItem1;
            this.bindingNavigator3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem1,
            this.bindingNavigatorMovePreviousItem1,
            this.bindingNavigatorSeparator3,
            this.bindingNavigatorPositionItem1,
            this.bindingNavigatorCountItem1,
            this.bindingNavigatorSeparator4,
            this.bindingNavigatorMoveNextItem1,
            this.bindingNavigatorMoveLastItem1,
            this.bindingNavigatorSeparator5,
            this.bindingNavigatorAddNewItem1,
            this.bindingNavigatorDeleteItem1,
            this.toolStripButton9});
            this.bindingNavigator3.Location = new System.Drawing.Point(3, 3);
            this.bindingNavigator3.MoveFirstItem = this.bindingNavigatorMoveFirstItem1;
            this.bindingNavigator3.MoveLastItem = this.bindingNavigatorMoveLastItem1;
            this.bindingNavigator3.MoveNextItem = this.bindingNavigatorMoveNextItem1;
            this.bindingNavigator3.MovePreviousItem = this.bindingNavigatorMovePreviousItem1;
            this.bindingNavigator3.Name = "bindingNavigator3";
            this.bindingNavigator3.PositionItem = this.bindingNavigatorPositionItem1;
            this.bindingNavigator3.Size = new System.Drawing.Size(1050, 25);
            this.bindingNavigator3.TabIndex = 1;
            this.bindingNavigator3.Text = "bindingNavigator3";
            // 
            // bindingNavigatorAddNewItem1
            // 
            this.bindingNavigatorAddNewItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem1.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem1.Image")));
            this.bindingNavigatorAddNewItem1.Name = "bindingNavigatorAddNewItem1";
            this.bindingNavigatorAddNewItem1.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem1.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem1.Text = "Добавить";
            // 
            // bindingNavigatorCountItem1
            // 
            this.bindingNavigatorCountItem1.Name = "bindingNavigatorCountItem1";
            this.bindingNavigatorCountItem1.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem1.Text = "для {0}";
            this.bindingNavigatorCountItem1.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorDeleteItem1
            // 
            this.bindingNavigatorDeleteItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem1.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem1.Image")));
            this.bindingNavigatorDeleteItem1.Name = "bindingNavigatorDeleteItem1";
            this.bindingNavigatorDeleteItem1.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem1.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem1.Text = "Удалить";
            // 
            // bindingNavigatorMoveFirstItem1
            // 
            this.bindingNavigatorMoveFirstItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem1.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem1.Image")));
            this.bindingNavigatorMoveFirstItem1.Name = "bindingNavigatorMoveFirstItem1";
            this.bindingNavigatorMoveFirstItem1.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem1.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem1.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem1
            // 
            this.bindingNavigatorMovePreviousItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem1.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem1.Image")));
            this.bindingNavigatorMovePreviousItem1.Name = "bindingNavigatorMovePreviousItem1";
            this.bindingNavigatorMovePreviousItem1.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem1.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem1.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator3
            // 
            this.bindingNavigatorSeparator3.Name = "bindingNavigatorSeparator3";
            this.bindingNavigatorSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem1
            // 
            this.bindingNavigatorPositionItem1.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem1.AutoSize = false;
            this.bindingNavigatorPositionItem1.Name = "bindingNavigatorPositionItem1";
            this.bindingNavigatorPositionItem1.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem1.Text = "0";
            this.bindingNavigatorPositionItem1.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator4
            // 
            this.bindingNavigatorSeparator4.Name = "bindingNavigatorSeparator4";
            this.bindingNavigatorSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem1
            // 
            this.bindingNavigatorMoveNextItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem1.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem1.Image")));
            this.bindingNavigatorMoveNextItem1.Name = "bindingNavigatorMoveNextItem1";
            this.bindingNavigatorMoveNextItem1.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem1.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem1.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem1
            // 
            this.bindingNavigatorMoveLastItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem1.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem1.Image")));
            this.bindingNavigatorMoveLastItem1.Name = "bindingNavigatorMoveLastItem1";
            this.bindingNavigatorMoveLastItem1.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem1.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem1.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator5
            // 
            this.bindingNavigatorSeparator5.Name = "bindingNavigatorSeparator5";
            this.bindingNavigatorSeparator5.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton9
            // 
            this.toolStripButton9.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton9.Image")));
            this.toolStripButton9.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton9.Name = "toolStripButton9";
            this.toolStripButton9.Size = new System.Drawing.Size(75, 22);
            this.toolStripButton9.Text = "Оновити";
            this.toolStripButton9.Click += new System.EventHandler(this.toolStripButton9_Click);
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage4);
            this.tabControl2.Controls.Add(this.tabPage3);
            this.tabControl2.Location = new System.Drawing.Point(0, 27);
            this.tabControl2.MaximumSize = new System.Drawing.Size(1680, 1050);
            this.tabControl2.MinimumSize = new System.Drawing.Size(800, 600);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(1064, 600);
            this.tabControl2.TabIndex = 2;
            this.tabControl2.Visible = false;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.bindingNavigator4);
            this.tabPage4.Controls.Add(this.type_ZapDataGridView);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1056, 574);
            this.tabPage4.TabIndex = 1;
            this.tabPage4.Text = "Тип запчастин";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // bindingNavigator4
            // 
            this.bindingNavigator4.AddNewItem = this.toolStripButton17;
            this.bindingNavigator4.BindingSource = this.typeZapBindingSource;
            this.bindingNavigator4.CountItem = this.toolStripLabel3;
            this.bindingNavigator4.DeleteItem = this.toolStripButton18;
            this.bindingNavigator4.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton19,
            this.toolStripButton20,
            this.toolStripSeparator7,
            this.toolStripTextBox3,
            this.toolStripLabel3,
            this.toolStripSeparator8,
            this.toolStripButton21,
            this.toolStripButton22,
            this.toolStripSeparator9,
            this.toolStripButton17,
            this.toolStripButton18,
            this.toolStripButton23});
            this.bindingNavigator4.Location = new System.Drawing.Point(3, 3);
            this.bindingNavigator4.MoveFirstItem = this.toolStripButton19;
            this.bindingNavigator4.MoveLastItem = this.toolStripButton22;
            this.bindingNavigator4.MoveNextItem = this.toolStripButton21;
            this.bindingNavigator4.MovePreviousItem = this.toolStripButton20;
            this.bindingNavigator4.Name = "bindingNavigator4";
            this.bindingNavigator4.PositionItem = this.toolStripTextBox3;
            this.bindingNavigator4.Size = new System.Drawing.Size(1050, 25);
            this.bindingNavigator4.TabIndex = 2;
            this.bindingNavigator4.Text = "bindingNavigator4";
            // 
            // toolStripButton17
            // 
            this.toolStripButton17.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton17.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton17.Image")));
            this.toolStripButton17.Name = "toolStripButton17";
            this.toolStripButton17.RightToLeftAutoMirrorImage = true;
            this.toolStripButton17.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton17.Text = "Добавить";
            // 
            // toolStripLabel3
            // 
            this.toolStripLabel3.Name = "toolStripLabel3";
            this.toolStripLabel3.Size = new System.Drawing.Size(43, 22);
            this.toolStripLabel3.Text = "для {0}";
            this.toolStripLabel3.ToolTipText = "Общее число элементов";
            // 
            // toolStripButton18
            // 
            this.toolStripButton18.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton18.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton18.Image")));
            this.toolStripButton18.Name = "toolStripButton18";
            this.toolStripButton18.RightToLeftAutoMirrorImage = true;
            this.toolStripButton18.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton18.Text = "Удалить";
            // 
            // toolStripButton19
            // 
            this.toolStripButton19.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton19.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton19.Image")));
            this.toolStripButton19.Name = "toolStripButton19";
            this.toolStripButton19.RightToLeftAutoMirrorImage = true;
            this.toolStripButton19.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton19.Text = "Переместить в начало";
            // 
            // toolStripButton20
            // 
            this.toolStripButton20.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton20.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton20.Image")));
            this.toolStripButton20.Name = "toolStripButton20";
            this.toolStripButton20.RightToLeftAutoMirrorImage = true;
            this.toolStripButton20.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton20.Text = "Переместить назад";
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripTextBox3
            // 
            this.toolStripTextBox3.AccessibleName = "Положение";
            this.toolStripTextBox3.AutoSize = false;
            this.toolStripTextBox3.Name = "toolStripTextBox3";
            this.toolStripTextBox3.Size = new System.Drawing.Size(50, 23);
            this.toolStripTextBox3.Text = "0";
            this.toolStripTextBox3.ToolTipText = "Текущее положение";
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton21
            // 
            this.toolStripButton21.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton21.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton21.Image")));
            this.toolStripButton21.Name = "toolStripButton21";
            this.toolStripButton21.RightToLeftAutoMirrorImage = true;
            this.toolStripButton21.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton21.Text = "Переместить вперед";
            // 
            // toolStripButton22
            // 
            this.toolStripButton22.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton22.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton22.Image")));
            this.toolStripButton22.Name = "toolStripButton22";
            this.toolStripButton22.RightToLeftAutoMirrorImage = true;
            this.toolStripButton22.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton22.Text = "Переместить в конец";
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton23
            // 
            this.toolStripButton23.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton23.Image")));
            this.toolStripButton23.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton23.Name = "toolStripButton23";
            this.toolStripButton23.Size = new System.Drawing.Size(75, 22);
            this.toolStripButton23.Text = "Оновити";
            this.toolStripButton23.Click += new System.EventHandler(this.toolStripButton23_Click);
            // 
            // type_ZapDataGridView
            // 
            this.type_ZapDataGridView.AutoGenerateColumns = false;
            this.type_ZapDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.type_ZapDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDTypeZapDataGridViewTextBoxColumn,
            this.nazvanieDataGridViewTextBoxColumn});
            this.type_ZapDataGridView.DataSource = this.typeZapBindingSource;
            this.type_ZapDataGridView.Location = new System.Drawing.Point(0, 30);
            this.type_ZapDataGridView.Name = "type_ZapDataGridView";
            this.type_ZapDataGridView.Size = new System.Drawing.Size(961, 346);
            this.type_ZapDataGridView.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.DataPropertyName = "Nazvanie";
            this.dataGridViewTextBoxColumn18.HeaderText = "Nazvanie";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.DataPropertyName = "ID_Type_Zap";
            this.dataGridViewTextBoxColumn17.HeaderText = "ID_Type_Zap";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            this.dataGridViewTextBoxColumn17.ReadOnly = true;
            // 
            // toolStripButton12
            // 
            this.toolStripButton12.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton12.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton12.Image")));
            this.toolStripButton12.Name = "toolStripButton12";
            this.toolStripButton12.RightToLeftAutoMirrorImage = true;
            this.toolStripButton12.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton12.Text = "Переместить в начало";
            // 
            // toolStripButton13
            // 
            this.toolStripButton13.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton13.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton13.Image")));
            this.toolStripButton13.Name = "toolStripButton13";
            this.toolStripButton13.RightToLeftAutoMirrorImage = true;
            this.toolStripButton13.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton13.Text = "Переместить назад";
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripTextBox2
            // 
            this.toolStripTextBox2.AccessibleName = "Положение";
            this.toolStripTextBox2.AutoSize = false;
            this.toolStripTextBox2.Name = "toolStripTextBox2";
            this.toolStripTextBox2.Size = new System.Drawing.Size(50, 23);
            this.toolStripTextBox2.Text = "0";
            this.toolStripTextBox2.ToolTipText = "Текущее положение";
            // 
            // toolStripLabel2
            // 
            this.toolStripLabel2.Name = "toolStripLabel2";
            this.toolStripLabel2.Size = new System.Drawing.Size(43, 22);
            this.toolStripLabel2.Text = "для {0}";
            this.toolStripLabel2.ToolTipText = "Общее число элементов";
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton14
            // 
            this.toolStripButton14.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton14.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton14.Image")));
            this.toolStripButton14.Name = "toolStripButton14";
            this.toolStripButton14.RightToLeftAutoMirrorImage = true;
            this.toolStripButton14.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton14.Text = "Переместить вперед";
            // 
            // toolStripButton15
            // 
            this.toolStripButton15.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton15.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton15.Image")));
            this.toolStripButton15.Name = "toolStripButton15";
            this.toolStripButton15.RightToLeftAutoMirrorImage = true;
            this.toolStripButton15.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton15.Text = "Переместить в конец";
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton10
            // 
            this.toolStripButton10.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton10.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton10.Image")));
            this.toolStripButton10.Name = "toolStripButton10";
            this.toolStripButton10.RightToLeftAutoMirrorImage = true;
            this.toolStripButton10.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton10.Text = "Добавить";
            // 
            // toolStripButton11
            // 
            this.toolStripButton11.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton11.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton11.Image")));
            this.toolStripButton11.Name = "toolStripButton11";
            this.toolStripButton11.RightToLeftAutoMirrorImage = true;
            this.toolStripButton11.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton11.Text = "Удалить";
            // 
            // toolStripButton16
            // 
            this.toolStripButton16.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton16.Image")));
            this.toolStripButton16.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton16.Name = "toolStripButton16";
            this.toolStripButton16.Size = new System.Drawing.Size(75, 22);
            this.toolStripButton16.Text = "Оновити";
            // 
            // tabControl3
            // 
            this.tabControl3.Controls.Add(this.tabPage5);
            this.tabControl3.Controls.Add(this.tabPage6);
            this.tabControl3.Location = new System.Drawing.Point(2, 27);
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(1219, 607);
            this.tabControl3.TabIndex = 3;
            this.tabControl3.Visible = false;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.bindingNavigator5);
            this.tabPage5.Controls.Add(this.prodaj_ZapDataGridView);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(1211, 581);
            this.tabPage5.TabIndex = 0;
            this.tabPage5.Text = "Продаж запчастин";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // bindingNavigator5
            // 
            this.bindingNavigator5.AddNewItem = this.toolStripButton24;
            this.bindingNavigator5.BindingSource = this.prodaj_ZapBindingSource;
            this.bindingNavigator5.CountItem = this.toolStripLabel4;
            this.bindingNavigator5.DeleteItem = this.toolStripButton25;
            this.bindingNavigator5.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton26,
            this.toolStripButton27,
            this.toolStripSeparator10,
            this.toolStripTextBox4,
            this.toolStripLabel4,
            this.toolStripSeparator11,
            this.toolStripButton28,
            this.toolStripButton29,
            this.toolStripSeparator12,
            this.toolStripButton24,
            this.toolStripButton25,
            this.toolStripButton30});
            this.bindingNavigator5.Location = new System.Drawing.Point(3, 3);
            this.bindingNavigator5.MoveFirstItem = this.toolStripButton26;
            this.bindingNavigator5.MoveLastItem = this.toolStripButton29;
            this.bindingNavigator5.MoveNextItem = this.toolStripButton28;
            this.bindingNavigator5.MovePreviousItem = this.toolStripButton27;
            this.bindingNavigator5.Name = "bindingNavigator5";
            this.bindingNavigator5.PositionItem = this.toolStripTextBox4;
            this.bindingNavigator5.Size = new System.Drawing.Size(1205, 25);
            this.bindingNavigator5.TabIndex = 3;
            this.bindingNavigator5.Text = "bindingNavigator5";
            // 
            // toolStripButton24
            // 
            this.toolStripButton24.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton24.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton24.Image")));
            this.toolStripButton24.Name = "toolStripButton24";
            this.toolStripButton24.RightToLeftAutoMirrorImage = true;
            this.toolStripButton24.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton24.Text = "Добавить";
            // 
            // toolStripLabel4
            // 
            this.toolStripLabel4.Name = "toolStripLabel4";
            this.toolStripLabel4.Size = new System.Drawing.Size(43, 22);
            this.toolStripLabel4.Text = "для {0}";
            this.toolStripLabel4.ToolTipText = "Общее число элементов";
            // 
            // toolStripButton25
            // 
            this.toolStripButton25.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton25.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton25.Image")));
            this.toolStripButton25.Name = "toolStripButton25";
            this.toolStripButton25.RightToLeftAutoMirrorImage = true;
            this.toolStripButton25.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton25.Text = "Удалить";
            // 
            // toolStripButton26
            // 
            this.toolStripButton26.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton26.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton26.Image")));
            this.toolStripButton26.Name = "toolStripButton26";
            this.toolStripButton26.RightToLeftAutoMirrorImage = true;
            this.toolStripButton26.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton26.Text = "Переместить в начало";
            // 
            // toolStripButton27
            // 
            this.toolStripButton27.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton27.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton27.Image")));
            this.toolStripButton27.Name = "toolStripButton27";
            this.toolStripButton27.RightToLeftAutoMirrorImage = true;
            this.toolStripButton27.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton27.Text = "Переместить назад";
            // 
            // toolStripSeparator10
            // 
            this.toolStripSeparator10.Name = "toolStripSeparator10";
            this.toolStripSeparator10.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripTextBox4
            // 
            this.toolStripTextBox4.AccessibleName = "Положение";
            this.toolStripTextBox4.AutoSize = false;
            this.toolStripTextBox4.Name = "toolStripTextBox4";
            this.toolStripTextBox4.Size = new System.Drawing.Size(50, 23);
            this.toolStripTextBox4.Text = "0";
            this.toolStripTextBox4.ToolTipText = "Текущее положение";
            // 
            // toolStripSeparator11
            // 
            this.toolStripSeparator11.Name = "toolStripSeparator11";
            this.toolStripSeparator11.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton28
            // 
            this.toolStripButton28.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton28.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton28.Image")));
            this.toolStripButton28.Name = "toolStripButton28";
            this.toolStripButton28.RightToLeftAutoMirrorImage = true;
            this.toolStripButton28.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton28.Text = "Переместить вперед";
            // 
            // toolStripButton29
            // 
            this.toolStripButton29.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton29.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton29.Image")));
            this.toolStripButton29.Name = "toolStripButton29";
            this.toolStripButton29.RightToLeftAutoMirrorImage = true;
            this.toolStripButton29.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton29.Text = "Переместить в конец";
            // 
            // toolStripSeparator12
            // 
            this.toolStripSeparator12.Name = "toolStripSeparator12";
            this.toolStripSeparator12.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton30
            // 
            this.toolStripButton30.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton30.Image")));
            this.toolStripButton30.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton30.Name = "toolStripButton30";
            this.toolStripButton30.Size = new System.Drawing.Size(75, 22);
            this.toolStripButton30.Text = "Оновити";
            this.toolStripButton30.Click += new System.EventHandler(this.toolStripButton30_Click);
            // 
            // prodaj_ZapDataGridView
            // 
            this.prodaj_ZapDataGridView.AutoGenerateColumns = false;
            this.prodaj_ZapDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.prodaj_ZapDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn19,
            this.dataGridViewTextBoxColumn20,
            this.dataGridViewTextBoxColumn21,
            this.dataGridViewTextBoxColumn22});
            this.prodaj_ZapDataGridView.DataSource = this.prodaj_ZapBindingSource;
            this.prodaj_ZapDataGridView.Location = new System.Drawing.Point(4, 31);
            this.prodaj_ZapDataGridView.Name = "prodaj_ZapDataGridView";
            this.prodaj_ZapDataGridView.Size = new System.Drawing.Size(550, 183);
            this.prodaj_ZapDataGridView.TabIndex = 0;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.bindingNavigator6);
            this.tabPage6.Controls.Add(this.prodaj_TehnDataGridView);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(1211, 581);
            this.tabPage6.TabIndex = 1;
            this.tabPage6.Text = "Продаж техніки";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // bindingNavigator6
            // 
            this.bindingNavigator6.AddNewItem = this.toolStripButton31;
            this.bindingNavigator6.BindingSource = this.prodaj_TehnBindingSource;
            this.bindingNavigator6.CountItem = this.toolStripLabel5;
            this.bindingNavigator6.DeleteItem = this.toolStripButton32;
            this.bindingNavigator6.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton33,
            this.toolStripButton34,
            this.toolStripSeparator13,
            this.toolStripTextBox5,
            this.toolStripLabel5,
            this.toolStripSeparator14,
            this.toolStripButton35,
            this.toolStripButton36,
            this.toolStripSeparator15,
            this.toolStripButton31,
            this.toolStripButton32,
            this.toolStripButton37});
            this.bindingNavigator6.Location = new System.Drawing.Point(3, 3);
            this.bindingNavigator6.MoveFirstItem = this.toolStripButton33;
            this.bindingNavigator6.MoveLastItem = this.toolStripButton36;
            this.bindingNavigator6.MoveNextItem = this.toolStripButton35;
            this.bindingNavigator6.MovePreviousItem = this.toolStripButton34;
            this.bindingNavigator6.Name = "bindingNavigator6";
            this.bindingNavigator6.PositionItem = this.toolStripTextBox5;
            this.bindingNavigator6.Size = new System.Drawing.Size(1205, 25);
            this.bindingNavigator6.TabIndex = 3;
            this.bindingNavigator6.Text = "bindingNavigator6";
            // 
            // toolStripButton31
            // 
            this.toolStripButton31.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton31.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton31.Image")));
            this.toolStripButton31.Name = "toolStripButton31";
            this.toolStripButton31.RightToLeftAutoMirrorImage = true;
            this.toolStripButton31.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton31.Text = "Добавить";
            // 
            // toolStripLabel5
            // 
            this.toolStripLabel5.Name = "toolStripLabel5";
            this.toolStripLabel5.Size = new System.Drawing.Size(43, 22);
            this.toolStripLabel5.Text = "для {0}";
            this.toolStripLabel5.ToolTipText = "Общее число элементов";
            // 
            // toolStripButton32
            // 
            this.toolStripButton32.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton32.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton32.Image")));
            this.toolStripButton32.Name = "toolStripButton32";
            this.toolStripButton32.RightToLeftAutoMirrorImage = true;
            this.toolStripButton32.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton32.Text = "Удалить";
            // 
            // toolStripButton33
            // 
            this.toolStripButton33.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton33.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton33.Image")));
            this.toolStripButton33.Name = "toolStripButton33";
            this.toolStripButton33.RightToLeftAutoMirrorImage = true;
            this.toolStripButton33.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton33.Text = "Переместить в начало";
            // 
            // toolStripButton34
            // 
            this.toolStripButton34.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton34.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton34.Image")));
            this.toolStripButton34.Name = "toolStripButton34";
            this.toolStripButton34.RightToLeftAutoMirrorImage = true;
            this.toolStripButton34.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton34.Text = "Переместить назад";
            // 
            // toolStripSeparator13
            // 
            this.toolStripSeparator13.Name = "toolStripSeparator13";
            this.toolStripSeparator13.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripTextBox5
            // 
            this.toolStripTextBox5.AccessibleName = "Положение";
            this.toolStripTextBox5.AutoSize = false;
            this.toolStripTextBox5.Name = "toolStripTextBox5";
            this.toolStripTextBox5.Size = new System.Drawing.Size(50, 23);
            this.toolStripTextBox5.Text = "0";
            this.toolStripTextBox5.ToolTipText = "Текущее положение";
            // 
            // toolStripSeparator14
            // 
            this.toolStripSeparator14.Name = "toolStripSeparator14";
            this.toolStripSeparator14.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton35
            // 
            this.toolStripButton35.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton35.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton35.Image")));
            this.toolStripButton35.Name = "toolStripButton35";
            this.toolStripButton35.RightToLeftAutoMirrorImage = true;
            this.toolStripButton35.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton35.Text = "Переместить вперед";
            // 
            // toolStripButton36
            // 
            this.toolStripButton36.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton36.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton36.Image")));
            this.toolStripButton36.Name = "toolStripButton36";
            this.toolStripButton36.RightToLeftAutoMirrorImage = true;
            this.toolStripButton36.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton36.Text = "Переместить в конец";
            // 
            // toolStripSeparator15
            // 
            this.toolStripSeparator15.Name = "toolStripSeparator15";
            this.toolStripSeparator15.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton37
            // 
            this.toolStripButton37.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton37.Image")));
            this.toolStripButton37.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton37.Name = "toolStripButton37";
            this.toolStripButton37.Size = new System.Drawing.Size(75, 22);
            this.toolStripButton37.Text = "Оновити";
            this.toolStripButton37.Click += new System.EventHandler(this.toolStripButton37_Click);
            // 
            // prodaj_TehnDataGridView
            // 
            this.prodaj_TehnDataGridView.AutoGenerateColumns = false;
            this.prodaj_TehnDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.prodaj_TehnDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn23,
            this.Date_Z,
            this.dataGridViewTextBoxColumn25,
            this.dataGridViewTextBoxColumn24,
            this.comments});
            this.prodaj_TehnDataGridView.DataSource = this.prodaj_TehnBindingSource;
            this.prodaj_TehnDataGridView.Location = new System.Drawing.Point(6, 31);
            this.prodaj_TehnDataGridView.Name = "prodaj_TehnDataGridView";
            this.prodaj_TehnDataGridView.Size = new System.Drawing.Size(875, 543);
            this.prodaj_TehnDataGridView.TabIndex = 0;
            // 
            // Date_Z
            // 
            this.Date_Z.HeaderText = "Дата продажу";
            this.Date_Z.MaxInputLength = 10;
            this.Date_Z.Name = "Date_Z";
            this.Date_Z.Width = 105;
            // 
            // comments
            // 
            this.comments.HeaderText = "Коментар";
            this.comments.Name = "comments";
            this.comments.Width = 350;
            // 
            // tabControl4
            // 
            this.tabControl4.Controls.Add(this.tabPage7);
            this.tabControl4.Controls.Add(this.tabPage8);
            this.tabControl4.Location = new System.Drawing.Point(2, 27);
            this.tabControl4.Name = "tabControl4";
            this.tabControl4.SelectedIndex = 0;
            this.tabControl4.Size = new System.Drawing.Size(1062, 503);
            this.tabControl4.TabIndex = 4;
            this.tabControl4.Visible = false;
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.bindingNavigator7);
            this.tabPage7.Controls.Add(this.zdiysn_PoslugiDataGridView);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(1054, 477);
            this.tabPage7.TabIndex = 0;
            this.tabPage7.Text = "Надані послуги";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // bindingNavigator7
            // 
            this.bindingNavigator7.AddNewItem = this.toolStripButton38;
            this.bindingNavigator7.BindingSource = this.zdiysn_PoslugiBindingSource;
            this.bindingNavigator7.CountItem = this.toolStripLabel6;
            this.bindingNavigator7.DeleteItem = this.toolStripButton39;
            this.bindingNavigator7.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton40,
            this.toolStripButton41,
            this.toolStripSeparator16,
            this.toolStripTextBox6,
            this.toolStripLabel6,
            this.toolStripSeparator17,
            this.toolStripButton42,
            this.toolStripButton43,
            this.toolStripSeparator18,
            this.toolStripButton38,
            this.toolStripButton39,
            this.toolStripButton44});
            this.bindingNavigator7.Location = new System.Drawing.Point(3, 3);
            this.bindingNavigator7.MoveFirstItem = this.toolStripButton40;
            this.bindingNavigator7.MoveLastItem = this.toolStripButton43;
            this.bindingNavigator7.MoveNextItem = this.toolStripButton42;
            this.bindingNavigator7.MovePreviousItem = this.toolStripButton41;
            this.bindingNavigator7.Name = "bindingNavigator7";
            this.bindingNavigator7.PositionItem = this.toolStripTextBox6;
            this.bindingNavigator7.Size = new System.Drawing.Size(1048, 25);
            this.bindingNavigator7.TabIndex = 4;
            this.bindingNavigator7.Text = "bindingNavigator7";
            // 
            // toolStripButton38
            // 
            this.toolStripButton38.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton38.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton38.Image")));
            this.toolStripButton38.Name = "toolStripButton38";
            this.toolStripButton38.RightToLeftAutoMirrorImage = true;
            this.toolStripButton38.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton38.Text = "Добавить";
            // 
            // toolStripLabel6
            // 
            this.toolStripLabel6.Name = "toolStripLabel6";
            this.toolStripLabel6.Size = new System.Drawing.Size(43, 22);
            this.toolStripLabel6.Text = "для {0}";
            this.toolStripLabel6.ToolTipText = "Общее число элементов";
            // 
            // toolStripButton39
            // 
            this.toolStripButton39.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton39.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton39.Image")));
            this.toolStripButton39.Name = "toolStripButton39";
            this.toolStripButton39.RightToLeftAutoMirrorImage = true;
            this.toolStripButton39.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton39.Text = "Удалить";
            // 
            // toolStripButton40
            // 
            this.toolStripButton40.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton40.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton40.Image")));
            this.toolStripButton40.Name = "toolStripButton40";
            this.toolStripButton40.RightToLeftAutoMirrorImage = true;
            this.toolStripButton40.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton40.Text = "Переместить в начало";
            // 
            // toolStripButton41
            // 
            this.toolStripButton41.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton41.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton41.Image")));
            this.toolStripButton41.Name = "toolStripButton41";
            this.toolStripButton41.RightToLeftAutoMirrorImage = true;
            this.toolStripButton41.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton41.Text = "Переместить назад";
            // 
            // toolStripSeparator16
            // 
            this.toolStripSeparator16.Name = "toolStripSeparator16";
            this.toolStripSeparator16.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripTextBox6
            // 
            this.toolStripTextBox6.AccessibleName = "Положение";
            this.toolStripTextBox6.AutoSize = false;
            this.toolStripTextBox6.Name = "toolStripTextBox6";
            this.toolStripTextBox6.Size = new System.Drawing.Size(50, 23);
            this.toolStripTextBox6.Text = "0";
            this.toolStripTextBox6.ToolTipText = "Текущее положение";
            // 
            // toolStripSeparator17
            // 
            this.toolStripSeparator17.Name = "toolStripSeparator17";
            this.toolStripSeparator17.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton42
            // 
            this.toolStripButton42.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton42.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton42.Image")));
            this.toolStripButton42.Name = "toolStripButton42";
            this.toolStripButton42.RightToLeftAutoMirrorImage = true;
            this.toolStripButton42.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton42.Text = "Переместить вперед";
            // 
            // toolStripButton43
            // 
            this.toolStripButton43.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton43.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton43.Image")));
            this.toolStripButton43.Name = "toolStripButton43";
            this.toolStripButton43.RightToLeftAutoMirrorImage = true;
            this.toolStripButton43.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton43.Text = "Переместить в конец";
            // 
            // toolStripSeparator18
            // 
            this.toolStripSeparator18.Name = "toolStripSeparator18";
            this.toolStripSeparator18.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton44
            // 
            this.toolStripButton44.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton44.Image")));
            this.toolStripButton44.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton44.Name = "toolStripButton44";
            this.toolStripButton44.Size = new System.Drawing.Size(75, 22);
            this.toolStripButton44.Text = "Оновити";
            this.toolStripButton44.Click += new System.EventHandler(this.toolStripButton44_Click);
            // 
            // zdiysn_PoslugiDataGridView
            // 
            this.zdiysn_PoslugiDataGridView.AutoGenerateColumns = false;
            this.zdiysn_PoslugiDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.zdiysn_PoslugiDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn26,
            this.dataGridViewTextBoxColumn27,
            this.dataGridViewTextBoxColumn28,
            this.dataGridViewTextBoxColumn29,
            this.dataGridViewTextBoxColumn30,
            this.dataGridViewTextBoxColumn31});
            this.zdiysn_PoslugiDataGridView.DataSource = this.zdiysn_PoslugiBindingSource;
            this.zdiysn_PoslugiDataGridView.Location = new System.Drawing.Point(3, 30);
            this.zdiysn_PoslugiDataGridView.Name = "zdiysn_PoslugiDataGridView";
            this.zdiysn_PoslugiDataGridView.Size = new System.Drawing.Size(932, 220);
            this.zdiysn_PoslugiDataGridView.TabIndex = 0;
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.poslugaDataGridView);
            this.tabPage8.Controls.Add(this.bindingNavigator8);
            this.tabPage8.Location = new System.Drawing.Point(4, 22);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(1054, 477);
            this.tabPage8.TabIndex = 1;
            this.tabPage8.Text = "Послуги";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // poslugaDataGridView
            // 
            this.poslugaDataGridView.AutoGenerateColumns = false;
            this.poslugaDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.poslugaDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn32,
            this.dataGridViewTextBoxColumn33,
            this.dataGridViewTextBoxColumn34});
            this.poslugaDataGridView.DataSource = this.poslugaBindingSource;
            this.poslugaDataGridView.Location = new System.Drawing.Point(0, 31);
            this.poslugaDataGridView.Name = "poslugaDataGridView";
            this.poslugaDataGridView.Size = new System.Drawing.Size(496, 220);
            this.poslugaDataGridView.TabIndex = 4;
            // 
            // bindingNavigator8
            // 
            this.bindingNavigator8.AddNewItem = this.toolStripButton45;
            this.bindingNavigator8.BindingSource = this.poslugaBindingSource;
            this.bindingNavigator8.CountItem = this.toolStripLabel7;
            this.bindingNavigator8.DeleteItem = this.toolStripButton46;
            this.bindingNavigator8.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton47,
            this.toolStripButton48,
            this.toolStripSeparator19,
            this.toolStripTextBox7,
            this.toolStripLabel7,
            this.toolStripSeparator20,
            this.toolStripButton49,
            this.toolStripButton50,
            this.toolStripSeparator21,
            this.toolStripButton45,
            this.toolStripButton46,
            this.toolStripButton51});
            this.bindingNavigator8.Location = new System.Drawing.Point(3, 3);
            this.bindingNavigator8.MoveFirstItem = this.toolStripButton47;
            this.bindingNavigator8.MoveLastItem = this.toolStripButton50;
            this.bindingNavigator8.MoveNextItem = this.toolStripButton49;
            this.bindingNavigator8.MovePreviousItem = this.toolStripButton48;
            this.bindingNavigator8.Name = "bindingNavigator8";
            this.bindingNavigator8.PositionItem = this.toolStripTextBox7;
            this.bindingNavigator8.Size = new System.Drawing.Size(1048, 25);
            this.bindingNavigator8.TabIndex = 4;
            this.bindingNavigator8.Text = "bindingNavigator8";
            // 
            // toolStripButton45
            // 
            this.toolStripButton45.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton45.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton45.Image")));
            this.toolStripButton45.Name = "toolStripButton45";
            this.toolStripButton45.RightToLeftAutoMirrorImage = true;
            this.toolStripButton45.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton45.Text = "Добавить";
            // 
            // toolStripLabel7
            // 
            this.toolStripLabel7.Name = "toolStripLabel7";
            this.toolStripLabel7.Size = new System.Drawing.Size(43, 22);
            this.toolStripLabel7.Text = "для {0}";
            this.toolStripLabel7.ToolTipText = "Общее число элементов";
            // 
            // toolStripButton46
            // 
            this.toolStripButton46.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton46.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton46.Image")));
            this.toolStripButton46.Name = "toolStripButton46";
            this.toolStripButton46.RightToLeftAutoMirrorImage = true;
            this.toolStripButton46.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton46.Text = "Удалить";
            // 
            // toolStripButton47
            // 
            this.toolStripButton47.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton47.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton47.Image")));
            this.toolStripButton47.Name = "toolStripButton47";
            this.toolStripButton47.RightToLeftAutoMirrorImage = true;
            this.toolStripButton47.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton47.Text = "Переместить в начало";
            // 
            // toolStripButton48
            // 
            this.toolStripButton48.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton48.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton48.Image")));
            this.toolStripButton48.Name = "toolStripButton48";
            this.toolStripButton48.RightToLeftAutoMirrorImage = true;
            this.toolStripButton48.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton48.Text = "Переместить назад";
            // 
            // toolStripSeparator19
            // 
            this.toolStripSeparator19.Name = "toolStripSeparator19";
            this.toolStripSeparator19.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripTextBox7
            // 
            this.toolStripTextBox7.AccessibleName = "Положение";
            this.toolStripTextBox7.AutoSize = false;
            this.toolStripTextBox7.Name = "toolStripTextBox7";
            this.toolStripTextBox7.Size = new System.Drawing.Size(50, 23);
            this.toolStripTextBox7.Text = "0";
            this.toolStripTextBox7.ToolTipText = "Текущее положение";
            // 
            // toolStripSeparator20
            // 
            this.toolStripSeparator20.Name = "toolStripSeparator20";
            this.toolStripSeparator20.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton49
            // 
            this.toolStripButton49.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton49.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton49.Image")));
            this.toolStripButton49.Name = "toolStripButton49";
            this.toolStripButton49.RightToLeftAutoMirrorImage = true;
            this.toolStripButton49.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton49.Text = "Переместить вперед";
            // 
            // toolStripButton50
            // 
            this.toolStripButton50.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton50.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton50.Image")));
            this.toolStripButton50.Name = "toolStripButton50";
            this.toolStripButton50.RightToLeftAutoMirrorImage = true;
            this.toolStripButton50.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton50.Text = "Переместить в конец";
            // 
            // toolStripSeparator21
            // 
            this.toolStripSeparator21.Name = "toolStripSeparator21";
            this.toolStripSeparator21.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton51
            // 
            this.toolStripButton51.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton51.Image")));
            this.toolStripButton51.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton51.Name = "toolStripButton51";
            this.toolStripButton51.Size = new System.Drawing.Size(75, 22);
            this.toolStripButton51.Text = "Оновити";
            this.toolStripButton51.Click += new System.EventHandler(this.toolStripButton51_Click);
            // 
            // tabControl5
            // 
            this.tabControl5.Controls.Add(this.tabPage9);
            this.tabControl5.Controls.Add(this.tabPage11);
            this.tabControl5.Controls.Add(this.tabPage10);
            this.tabControl5.Location = new System.Drawing.Point(2, 27);
            this.tabControl5.Name = "tabControl5";
            this.tabControl5.SelectedIndex = 0;
            this.tabControl5.Size = new System.Drawing.Size(1062, 600);
            this.tabControl5.TabIndex = 5;
            this.tabControl5.Visible = false;
            // 
            // tabPage9
            // 
            this.tabPage9.Controls.Add(this.bindingNavigator9);
            this.tabPage9.Controls.Add(this.tehnikaDataGridView);
            this.tabPage9.Location = new System.Drawing.Point(4, 22);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage9.Size = new System.Drawing.Size(1054, 574);
            this.tabPage9.TabIndex = 0;
            this.tabPage9.Text = "Техніка";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // bindingNavigator9
            // 
            this.bindingNavigator9.AddNewItem = this.toolStripButton52;
            this.bindingNavigator9.BindingSource = this.tehnikaBindingSource;
            this.bindingNavigator9.CountItem = this.toolStripLabel8;
            this.bindingNavigator9.DeleteItem = this.toolStripButton53;
            this.bindingNavigator9.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton54,
            this.toolStripButton55,
            this.toolStripSeparator22,
            this.toolStripTextBox8,
            this.toolStripLabel8,
            this.toolStripSeparator23,
            this.toolStripButton56,
            this.toolStripButton57,
            this.toolStripSeparator24,
            this.toolStripButton52,
            this.toolStripButton53,
            this.toolStripButton58});
            this.bindingNavigator9.Location = new System.Drawing.Point(3, 3);
            this.bindingNavigator9.MoveFirstItem = this.toolStripButton54;
            this.bindingNavigator9.MoveLastItem = this.toolStripButton57;
            this.bindingNavigator9.MoveNextItem = this.toolStripButton56;
            this.bindingNavigator9.MovePreviousItem = this.toolStripButton55;
            this.bindingNavigator9.Name = "bindingNavigator9";
            this.bindingNavigator9.PositionItem = this.toolStripTextBox8;
            this.bindingNavigator9.Size = new System.Drawing.Size(1048, 25);
            this.bindingNavigator9.TabIndex = 3;
            this.bindingNavigator9.Text = "bindingNavigator9";
            // 
            // toolStripButton52
            // 
            this.toolStripButton52.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton52.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton52.Image")));
            this.toolStripButton52.Name = "toolStripButton52";
            this.toolStripButton52.RightToLeftAutoMirrorImage = true;
            this.toolStripButton52.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton52.Text = "Добавить";
            // 
            // toolStripLabel8
            // 
            this.toolStripLabel8.Name = "toolStripLabel8";
            this.toolStripLabel8.Size = new System.Drawing.Size(43, 22);
            this.toolStripLabel8.Text = "для {0}";
            this.toolStripLabel8.ToolTipText = "Общее число элементов";
            // 
            // toolStripButton53
            // 
            this.toolStripButton53.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton53.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton53.Image")));
            this.toolStripButton53.Name = "toolStripButton53";
            this.toolStripButton53.RightToLeftAutoMirrorImage = true;
            this.toolStripButton53.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton53.Text = "Удалить";
            // 
            // toolStripButton54
            // 
            this.toolStripButton54.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton54.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton54.Image")));
            this.toolStripButton54.Name = "toolStripButton54";
            this.toolStripButton54.RightToLeftAutoMirrorImage = true;
            this.toolStripButton54.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton54.Text = "Переместить в начало";
            // 
            // toolStripButton55
            // 
            this.toolStripButton55.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton55.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton55.Image")));
            this.toolStripButton55.Name = "toolStripButton55";
            this.toolStripButton55.RightToLeftAutoMirrorImage = true;
            this.toolStripButton55.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton55.Text = "Переместить назад";
            // 
            // toolStripSeparator22
            // 
            this.toolStripSeparator22.Name = "toolStripSeparator22";
            this.toolStripSeparator22.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripTextBox8
            // 
            this.toolStripTextBox8.AccessibleName = "Положение";
            this.toolStripTextBox8.AutoSize = false;
            this.toolStripTextBox8.Name = "toolStripTextBox8";
            this.toolStripTextBox8.Size = new System.Drawing.Size(50, 23);
            this.toolStripTextBox8.Text = "0";
            this.toolStripTextBox8.ToolTipText = "Текущее положение";
            // 
            // toolStripSeparator23
            // 
            this.toolStripSeparator23.Name = "toolStripSeparator23";
            this.toolStripSeparator23.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton56
            // 
            this.toolStripButton56.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton56.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton56.Image")));
            this.toolStripButton56.Name = "toolStripButton56";
            this.toolStripButton56.RightToLeftAutoMirrorImage = true;
            this.toolStripButton56.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton56.Text = "Переместить вперед";
            // 
            // toolStripButton57
            // 
            this.toolStripButton57.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton57.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton57.Image")));
            this.toolStripButton57.Name = "toolStripButton57";
            this.toolStripButton57.RightToLeftAutoMirrorImage = true;
            this.toolStripButton57.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton57.Text = "Переместить в конец";
            // 
            // toolStripSeparator24
            // 
            this.toolStripSeparator24.Name = "toolStripSeparator24";
            this.toolStripSeparator24.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton58
            // 
            this.toolStripButton58.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton58.Image")));
            this.toolStripButton58.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton58.Name = "toolStripButton58";
            this.toolStripButton58.Size = new System.Drawing.Size(75, 22);
            this.toolStripButton58.Text = "Оновити";
            this.toolStripButton58.Click += new System.EventHandler(this.toolStripButton58_Click);
            // 
            // tehnikaDataGridView
            // 
            this.tehnikaDataGridView.AutoGenerateColumns = false;
            this.tehnikaDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tehnikaDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn35,
            this.dataGridViewTextBoxColumn36,
            this.dataGridViewTextBoxColumn37,
            this.dataGridViewTextBoxColumn38,
            this.dataGridViewTextBoxColumn39,
            this.dataGridViewTextBoxColumn40,
            this.dataGridViewTextBoxColumn41});
            this.tehnikaDataGridView.DataSource = this.tehnikaBindingSource;
            this.tehnikaDataGridView.Location = new System.Drawing.Point(3, 31);
            this.tehnikaDataGridView.Name = "tehnikaDataGridView";
            this.tehnikaDataGridView.Size = new System.Drawing.Size(747, 220);
            this.tehnikaDataGridView.TabIndex = 0;
            // 
            // tabPage11
            // 
            this.tabPage11.Controls.Add(this.bindingNavigator11);
            this.tabPage11.Controls.Add(this.stanDataGridView);
            this.tabPage11.Location = new System.Drawing.Point(4, 22);
            this.tabPage11.Name = "tabPage11";
            this.tabPage11.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage11.Size = new System.Drawing.Size(1054, 574);
            this.tabPage11.TabIndex = 2;
            this.tabPage11.Text = "Стан";
            this.tabPage11.UseVisualStyleBackColor = true;
            // 
            // bindingNavigator11
            // 
            this.bindingNavigator11.AddNewItem = this.toolStripButton66;
            this.bindingNavigator11.BindingSource = this.stanBindingSource;
            this.bindingNavigator11.CountItem = this.toolStripLabel10;
            this.bindingNavigator11.DeleteItem = this.toolStripButton67;
            this.bindingNavigator11.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton68,
            this.toolStripButton69,
            this.toolStripSeparator28,
            this.toolStripTextBox10,
            this.toolStripLabel10,
            this.toolStripSeparator29,
            this.toolStripButton70,
            this.toolStripButton71,
            this.toolStripSeparator30,
            this.toolStripButton66,
            this.toolStripButton67,
            this.toolStripButton72});
            this.bindingNavigator11.Location = new System.Drawing.Point(3, 3);
            this.bindingNavigator11.MoveFirstItem = this.toolStripButton68;
            this.bindingNavigator11.MoveLastItem = this.toolStripButton71;
            this.bindingNavigator11.MoveNextItem = this.toolStripButton70;
            this.bindingNavigator11.MovePreviousItem = this.toolStripButton69;
            this.bindingNavigator11.Name = "bindingNavigator11";
            this.bindingNavigator11.PositionItem = this.toolStripTextBox10;
            this.bindingNavigator11.Size = new System.Drawing.Size(1048, 25);
            this.bindingNavigator11.TabIndex = 3;
            this.bindingNavigator11.Text = "bindingNavigator11";
            // 
            // toolStripButton66
            // 
            this.toolStripButton66.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton66.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton66.Image")));
            this.toolStripButton66.Name = "toolStripButton66";
            this.toolStripButton66.RightToLeftAutoMirrorImage = true;
            this.toolStripButton66.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton66.Text = "Добавить";
            // 
            // toolStripLabel10
            // 
            this.toolStripLabel10.Name = "toolStripLabel10";
            this.toolStripLabel10.Size = new System.Drawing.Size(43, 22);
            this.toolStripLabel10.Text = "для {0}";
            this.toolStripLabel10.ToolTipText = "Общее число элементов";
            // 
            // toolStripButton67
            // 
            this.toolStripButton67.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton67.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton67.Image")));
            this.toolStripButton67.Name = "toolStripButton67";
            this.toolStripButton67.RightToLeftAutoMirrorImage = true;
            this.toolStripButton67.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton67.Text = "Удалить";
            // 
            // toolStripButton68
            // 
            this.toolStripButton68.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton68.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton68.Image")));
            this.toolStripButton68.Name = "toolStripButton68";
            this.toolStripButton68.RightToLeftAutoMirrorImage = true;
            this.toolStripButton68.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton68.Text = "Переместить в начало";
            // 
            // toolStripButton69
            // 
            this.toolStripButton69.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton69.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton69.Image")));
            this.toolStripButton69.Name = "toolStripButton69";
            this.toolStripButton69.RightToLeftAutoMirrorImage = true;
            this.toolStripButton69.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton69.Text = "Переместить назад";
            // 
            // toolStripSeparator28
            // 
            this.toolStripSeparator28.Name = "toolStripSeparator28";
            this.toolStripSeparator28.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripTextBox10
            // 
            this.toolStripTextBox10.AccessibleName = "Положение";
            this.toolStripTextBox10.AutoSize = false;
            this.toolStripTextBox10.Name = "toolStripTextBox10";
            this.toolStripTextBox10.Size = new System.Drawing.Size(50, 23);
            this.toolStripTextBox10.Text = "0";
            this.toolStripTextBox10.ToolTipText = "Текущее положение";
            // 
            // toolStripSeparator29
            // 
            this.toolStripSeparator29.Name = "toolStripSeparator29";
            this.toolStripSeparator29.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton70
            // 
            this.toolStripButton70.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton70.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton70.Image")));
            this.toolStripButton70.Name = "toolStripButton70";
            this.toolStripButton70.RightToLeftAutoMirrorImage = true;
            this.toolStripButton70.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton70.Text = "Переместить вперед";
            // 
            // toolStripButton71
            // 
            this.toolStripButton71.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton71.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton71.Image")));
            this.toolStripButton71.Name = "toolStripButton71";
            this.toolStripButton71.RightToLeftAutoMirrorImage = true;
            this.toolStripButton71.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton71.Text = "Переместить в конец";
            // 
            // toolStripSeparator30
            // 
            this.toolStripSeparator30.Name = "toolStripSeparator30";
            this.toolStripSeparator30.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton72
            // 
            this.toolStripButton72.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton72.Image")));
            this.toolStripButton72.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton72.Name = "toolStripButton72";
            this.toolStripButton72.Size = new System.Drawing.Size(75, 22);
            this.toolStripButton72.Text = "Оновити";
            this.toolStripButton72.Click += new System.EventHandler(this.toolStripButton72_Click);
            // 
            // stanDataGridView
            // 
            this.stanDataGridView.AutoGenerateColumns = false;
            this.stanDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.stanDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn44,
            this.dataGridViewTextBoxColumn45});
            this.stanDataGridView.DataSource = this.stanBindingSource;
            this.stanDataGridView.Location = new System.Drawing.Point(3, 31);
            this.stanDataGridView.Name = "stanDataGridView";
            this.stanDataGridView.Size = new System.Drawing.Size(300, 220);
            this.stanDataGridView.TabIndex = 0;
            // 
            // tabPage10
            // 
            this.tabPage10.Controls.Add(this.bindingNavigator10);
            this.tabPage10.Controls.Add(this.tipDataGridView);
            this.tabPage10.Location = new System.Drawing.Point(4, 22);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage10.Size = new System.Drawing.Size(1054, 574);
            this.tabPage10.TabIndex = 1;
            this.tabPage10.Text = "Тип";
            this.tabPage10.UseVisualStyleBackColor = true;
            // 
            // bindingNavigator10
            // 
            this.bindingNavigator10.AddNewItem = this.toolStripButton59;
            this.bindingNavigator10.BindingSource = this.tipBindingSource;
            this.bindingNavigator10.CountItem = this.toolStripLabel9;
            this.bindingNavigator10.DeleteItem = this.toolStripButton60;
            this.bindingNavigator10.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton61,
            this.toolStripButton62,
            this.toolStripSeparator25,
            this.toolStripTextBox9,
            this.toolStripLabel9,
            this.toolStripSeparator26,
            this.toolStripButton63,
            this.toolStripButton64,
            this.toolStripSeparator27,
            this.toolStripButton59,
            this.toolStripButton60,
            this.toolStripButton65});
            this.bindingNavigator10.Location = new System.Drawing.Point(3, 3);
            this.bindingNavigator10.MoveFirstItem = this.toolStripButton61;
            this.bindingNavigator10.MoveLastItem = this.toolStripButton64;
            this.bindingNavigator10.MoveNextItem = this.toolStripButton63;
            this.bindingNavigator10.MovePreviousItem = this.toolStripButton62;
            this.bindingNavigator10.Name = "bindingNavigator10";
            this.bindingNavigator10.PositionItem = this.toolStripTextBox9;
            this.bindingNavigator10.Size = new System.Drawing.Size(1048, 25);
            this.bindingNavigator10.TabIndex = 3;
            this.bindingNavigator10.Text = "bindingNavigator10";
            // 
            // toolStripButton59
            // 
            this.toolStripButton59.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton59.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton59.Image")));
            this.toolStripButton59.Name = "toolStripButton59";
            this.toolStripButton59.RightToLeftAutoMirrorImage = true;
            this.toolStripButton59.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton59.Text = "Добавить";
            // 
            // toolStripLabel9
            // 
            this.toolStripLabel9.Name = "toolStripLabel9";
            this.toolStripLabel9.Size = new System.Drawing.Size(43, 22);
            this.toolStripLabel9.Text = "для {0}";
            this.toolStripLabel9.ToolTipText = "Общее число элементов";
            // 
            // toolStripButton60
            // 
            this.toolStripButton60.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton60.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton60.Image")));
            this.toolStripButton60.Name = "toolStripButton60";
            this.toolStripButton60.RightToLeftAutoMirrorImage = true;
            this.toolStripButton60.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton60.Text = "Удалить";
            // 
            // toolStripButton61
            // 
            this.toolStripButton61.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton61.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton61.Image")));
            this.toolStripButton61.Name = "toolStripButton61";
            this.toolStripButton61.RightToLeftAutoMirrorImage = true;
            this.toolStripButton61.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton61.Text = "Переместить в начало";
            // 
            // toolStripButton62
            // 
            this.toolStripButton62.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton62.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton62.Image")));
            this.toolStripButton62.Name = "toolStripButton62";
            this.toolStripButton62.RightToLeftAutoMirrorImage = true;
            this.toolStripButton62.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton62.Text = "Переместить назад";
            // 
            // toolStripSeparator25
            // 
            this.toolStripSeparator25.Name = "toolStripSeparator25";
            this.toolStripSeparator25.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripTextBox9
            // 
            this.toolStripTextBox9.AccessibleName = "Положение";
            this.toolStripTextBox9.AutoSize = false;
            this.toolStripTextBox9.Name = "toolStripTextBox9";
            this.toolStripTextBox9.Size = new System.Drawing.Size(50, 23);
            this.toolStripTextBox9.Text = "0";
            this.toolStripTextBox9.ToolTipText = "Текущее положение";
            // 
            // toolStripSeparator26
            // 
            this.toolStripSeparator26.Name = "toolStripSeparator26";
            this.toolStripSeparator26.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton63
            // 
            this.toolStripButton63.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton63.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton63.Image")));
            this.toolStripButton63.Name = "toolStripButton63";
            this.toolStripButton63.RightToLeftAutoMirrorImage = true;
            this.toolStripButton63.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton63.Text = "Переместить вперед";
            // 
            // toolStripButton64
            // 
            this.toolStripButton64.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton64.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton64.Image")));
            this.toolStripButton64.Name = "toolStripButton64";
            this.toolStripButton64.RightToLeftAutoMirrorImage = true;
            this.toolStripButton64.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton64.Text = "Переместить в конец";
            // 
            // toolStripSeparator27
            // 
            this.toolStripSeparator27.Name = "toolStripSeparator27";
            this.toolStripSeparator27.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton65
            // 
            this.toolStripButton65.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton65.Image")));
            this.toolStripButton65.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton65.Name = "toolStripButton65";
            this.toolStripButton65.Size = new System.Drawing.Size(75, 22);
            this.toolStripButton65.Text = "Оновити";
            this.toolStripButton65.Click += new System.EventHandler(this.toolStripButton65_Click);
            // 
            // tipDataGridView
            // 
            this.tipDataGridView.AutoGenerateColumns = false;
            this.tipDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tipDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn42,
            this.dataGridViewTextBoxColumn43});
            this.tipDataGridView.DataSource = this.tipBindingSource;
            this.tipDataGridView.Location = new System.Drawing.Point(1, 31);
            this.tipDataGridView.Name = "tipDataGridView";
            this.tipDataGridView.Size = new System.Drawing.Size(312, 220);
            this.tipDataGridView.TabIndex = 0;
            // 
            // tabPage12
            // 
            this.tabPage12.Controls.Add(this.akt_peredachi_v_remontDataGridView);
            this.tabPage12.Controls.Add(this.bindingNavigator12);
            this.tabPage12.Location = new System.Drawing.Point(4, 22);
            this.tabPage12.Name = "tabPage12";
            this.tabPage12.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage12.Size = new System.Drawing.Size(1215, 577);
            this.tabPage12.TabIndex = 0;
            this.tabPage12.Text = "Акт передачі в ремонт";
            this.tabPage12.UseVisualStyleBackColor = true;
            // 
            // bindingNavigator12
            // 
            this.bindingNavigator12.AddNewItem = this.toolStripButton73;
            this.bindingNavigator12.BindingSource = this.akt_peredachi_v_remontBindingSource;
            this.bindingNavigator12.CountItem = this.toolStripLabel11;
            this.bindingNavigator12.DeleteItem = this.toolStripButton74;
            this.bindingNavigator12.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton75,
            this.toolStripButton76,
            this.toolStripSeparator31,
            this.toolStripTextBox11,
            this.toolStripLabel11,
            this.toolStripSeparator32,
            this.toolStripButton77,
            this.toolStripButton78,
            this.toolStripSeparator33,
            this.toolStripButton73,
            this.toolStripButton74,
            this.toolStripButton79});
            this.bindingNavigator12.Location = new System.Drawing.Point(3, 3);
            this.bindingNavigator12.MoveFirstItem = this.toolStripButton75;
            this.bindingNavigator12.MoveLastItem = this.toolStripButton78;
            this.bindingNavigator12.MoveNextItem = this.toolStripButton77;
            this.bindingNavigator12.MovePreviousItem = this.toolStripButton76;
            this.bindingNavigator12.Name = "bindingNavigator12";
            this.bindingNavigator12.PositionItem = this.toolStripTextBox11;
            this.bindingNavigator12.Size = new System.Drawing.Size(1209, 25);
            this.bindingNavigator12.TabIndex = 4;
            this.bindingNavigator12.Text = "bindingNavigator12";
            // 
            // toolStripButton73
            // 
            this.toolStripButton73.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton73.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton73.Image")));
            this.toolStripButton73.Name = "toolStripButton73";
            this.toolStripButton73.RightToLeftAutoMirrorImage = true;
            this.toolStripButton73.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton73.Text = "Добавить";
            // 
            // toolStripLabel11
            // 
            this.toolStripLabel11.Name = "toolStripLabel11";
            this.toolStripLabel11.Size = new System.Drawing.Size(43, 22);
            this.toolStripLabel11.Text = "для {0}";
            this.toolStripLabel11.ToolTipText = "Общее число элементов";
            // 
            // toolStripButton74
            // 
            this.toolStripButton74.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton74.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton74.Image")));
            this.toolStripButton74.Name = "toolStripButton74";
            this.toolStripButton74.RightToLeftAutoMirrorImage = true;
            this.toolStripButton74.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton74.Text = "Удалить";
            // 
            // toolStripButton75
            // 
            this.toolStripButton75.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton75.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton75.Image")));
            this.toolStripButton75.Name = "toolStripButton75";
            this.toolStripButton75.RightToLeftAutoMirrorImage = true;
            this.toolStripButton75.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton75.Text = "Переместить в начало";
            // 
            // toolStripButton76
            // 
            this.toolStripButton76.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton76.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton76.Image")));
            this.toolStripButton76.Name = "toolStripButton76";
            this.toolStripButton76.RightToLeftAutoMirrorImage = true;
            this.toolStripButton76.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton76.Text = "Переместить назад";
            // 
            // toolStripSeparator31
            // 
            this.toolStripSeparator31.Name = "toolStripSeparator31";
            this.toolStripSeparator31.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripTextBox11
            // 
            this.toolStripTextBox11.AccessibleName = "Положение";
            this.toolStripTextBox11.AutoSize = false;
            this.toolStripTextBox11.Name = "toolStripTextBox11";
            this.toolStripTextBox11.Size = new System.Drawing.Size(50, 23);
            this.toolStripTextBox11.Text = "0";
            this.toolStripTextBox11.ToolTipText = "Текущее положение";
            // 
            // toolStripSeparator32
            // 
            this.toolStripSeparator32.Name = "toolStripSeparator32";
            this.toolStripSeparator32.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton77
            // 
            this.toolStripButton77.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton77.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton77.Image")));
            this.toolStripButton77.Name = "toolStripButton77";
            this.toolStripButton77.RightToLeftAutoMirrorImage = true;
            this.toolStripButton77.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton77.Text = "Переместить вперед";
            // 
            // toolStripButton78
            // 
            this.toolStripButton78.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton78.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton78.Image")));
            this.toolStripButton78.Name = "toolStripButton78";
            this.toolStripButton78.RightToLeftAutoMirrorImage = true;
            this.toolStripButton78.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton78.Text = "Переместить в конец";
            // 
            // toolStripSeparator33
            // 
            this.toolStripSeparator33.Name = "toolStripSeparator33";
            this.toolStripSeparator33.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton79
            // 
            this.toolStripButton79.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton79.Image")));
            this.toolStripButton79.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton79.Name = "toolStripButton79";
            this.toolStripButton79.Size = new System.Drawing.Size(75, 22);
            this.toolStripButton79.Text = "Оновити";
            this.toolStripButton79.Click += new System.EventHandler(this.toolStripButton79_Click);
            // 
            // tabControl6
            // 
            this.tabControl6.Controls.Add(this.tabPage12);
            this.tabControl6.Location = new System.Drawing.Point(2, 27);
            this.tabControl6.Name = "tabControl6";
            this.tabControl6.SelectedIndex = 0;
            this.tabControl6.Size = new System.Drawing.Size(1223, 603);
            this.tabControl6.TabIndex = 6;
            this.tabControl6.Visible = false;
            // 
            // tabControl7
            // 
            this.tabControl7.Controls.Add(this.tabPage13);
            this.tabControl7.Location = new System.Drawing.Point(2, 27);
            this.tabControl7.Name = "tabControl7";
            this.tabControl7.SelectedIndex = 0;
            this.tabControl7.Size = new System.Drawing.Size(1219, 607);
            this.tabControl7.TabIndex = 7;
            this.tabControl7.Visible = false;
            // 
            // tabPage13
            // 
            this.tabPage13.Controls.Add(this.bindingNavigator13);
            this.tabPage13.Controls.Add(this.pracivnukuDataGridView);
            this.tabPage13.Location = new System.Drawing.Point(4, 22);
            this.tabPage13.Name = "tabPage13";
            this.tabPage13.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage13.Size = new System.Drawing.Size(1211, 581);
            this.tabPage13.TabIndex = 0;
            this.tabPage13.Text = "Працівники";
            this.tabPage13.UseVisualStyleBackColor = true;
            // 
            // bindingNavigator13
            // 
            this.bindingNavigator13.AddNewItem = this.toolStripButton80;
            this.bindingNavigator13.BindingSource = this.pracivnukuBindingSource;
            this.bindingNavigator13.CountItem = this.toolStripLabel12;
            this.bindingNavigator13.DeleteItem = this.toolStripButton81;
            this.bindingNavigator13.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton82,
            this.toolStripButton83,
            this.toolStripSeparator34,
            this.toolStripTextBox12,
            this.toolStripLabel12,
            this.toolStripSeparator35,
            this.toolStripButton84,
            this.toolStripButton85,
            this.toolStripSeparator36,
            this.toolStripButton80,
            this.toolStripButton81,
            this.toolStripButton86});
            this.bindingNavigator13.Location = new System.Drawing.Point(3, 3);
            this.bindingNavigator13.MoveFirstItem = this.toolStripButton82;
            this.bindingNavigator13.MoveLastItem = this.toolStripButton85;
            this.bindingNavigator13.MoveNextItem = this.toolStripButton84;
            this.bindingNavigator13.MovePreviousItem = this.toolStripButton83;
            this.bindingNavigator13.Name = "bindingNavigator13";
            this.bindingNavigator13.PositionItem = this.toolStripTextBox12;
            this.bindingNavigator13.Size = new System.Drawing.Size(1205, 25);
            this.bindingNavigator13.TabIndex = 4;
            this.bindingNavigator13.Text = "bindingNavigator13";
            // 
            // toolStripButton80
            // 
            this.toolStripButton80.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton80.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton80.Image")));
            this.toolStripButton80.Name = "toolStripButton80";
            this.toolStripButton80.RightToLeftAutoMirrorImage = true;
            this.toolStripButton80.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton80.Text = "Добавить";
            // 
            // toolStripLabel12
            // 
            this.toolStripLabel12.Name = "toolStripLabel12";
            this.toolStripLabel12.Size = new System.Drawing.Size(43, 22);
            this.toolStripLabel12.Text = "для {0}";
            this.toolStripLabel12.ToolTipText = "Общее число элементов";
            // 
            // toolStripButton81
            // 
            this.toolStripButton81.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton81.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton81.Image")));
            this.toolStripButton81.Name = "toolStripButton81";
            this.toolStripButton81.RightToLeftAutoMirrorImage = true;
            this.toolStripButton81.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton81.Text = "Удалить";
            // 
            // toolStripButton82
            // 
            this.toolStripButton82.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton82.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton82.Image")));
            this.toolStripButton82.Name = "toolStripButton82";
            this.toolStripButton82.RightToLeftAutoMirrorImage = true;
            this.toolStripButton82.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton82.Text = "Переместить в начало";
            // 
            // toolStripButton83
            // 
            this.toolStripButton83.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton83.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton83.Image")));
            this.toolStripButton83.Name = "toolStripButton83";
            this.toolStripButton83.RightToLeftAutoMirrorImage = true;
            this.toolStripButton83.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton83.Text = "Переместить назад";
            // 
            // toolStripSeparator34
            // 
            this.toolStripSeparator34.Name = "toolStripSeparator34";
            this.toolStripSeparator34.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripTextBox12
            // 
            this.toolStripTextBox12.AccessibleName = "Положение";
            this.toolStripTextBox12.AutoSize = false;
            this.toolStripTextBox12.Name = "toolStripTextBox12";
            this.toolStripTextBox12.Size = new System.Drawing.Size(50, 23);
            this.toolStripTextBox12.Text = "0";
            this.toolStripTextBox12.ToolTipText = "Текущее положение";
            // 
            // toolStripSeparator35
            // 
            this.toolStripSeparator35.Name = "toolStripSeparator35";
            this.toolStripSeparator35.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton84
            // 
            this.toolStripButton84.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton84.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton84.Image")));
            this.toolStripButton84.Name = "toolStripButton84";
            this.toolStripButton84.RightToLeftAutoMirrorImage = true;
            this.toolStripButton84.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton84.Text = "Переместить вперед";
            // 
            // toolStripButton85
            // 
            this.toolStripButton85.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton85.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton85.Image")));
            this.toolStripButton85.Name = "toolStripButton85";
            this.toolStripButton85.RightToLeftAutoMirrorImage = true;
            this.toolStripButton85.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton85.Text = "Переместить в конец";
            // 
            // toolStripSeparator36
            // 
            this.toolStripSeparator36.Name = "toolStripSeparator36";
            this.toolStripSeparator36.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton86
            // 
            this.toolStripButton86.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton86.Image")));
            this.toolStripButton86.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton86.Name = "toolStripButton86";
            this.toolStripButton86.Size = new System.Drawing.Size(75, 22);
            this.toolStripButton86.Text = "Оновити";
            this.toolStripButton86.Click += new System.EventHandler(this.toolStripButton86_Click);
            // 
            // pracivnukuDataGridView
            // 
            this.pracivnukuDataGridView.AutoGenerateColumns = false;
            this.pracivnukuDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.pracivnukuDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn55,
            this.dataGridViewTextBoxColumn56,
            this.dataGridViewTextBoxColumn57,
            this.dataGridViewTextBoxColumn58,
            this.dataGridViewTextBoxColumn59});
            this.pracivnukuDataGridView.DataSource = this.pracivnukuBindingSource;
            this.pracivnukuDataGridView.Location = new System.Drawing.Point(3, 30);
            this.pracivnukuDataGridView.Name = "pracivnukuDataGridView";
            this.pracivnukuDataGridView.Size = new System.Drawing.Size(715, 220);
            this.pracivnukuDataGridView.TabIndex = 0;
            // 
            // servisniy_CentrDataSet
            // 
            this.servisniy_CentrDataSet.DataSetName = "Servisniy_CentrDataSet";
            this.servisniy_CentrDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tehnikaBindingSource
            // 
            this.tehnikaBindingSource.DataMember = "Tehnika";
            this.tehnikaBindingSource.DataSource = this.servisniy_CentrDataSet;
            // 
            // poslugaBindingSource
            // 
            this.poslugaBindingSource.DataMember = "Posluga";
            this.poslugaBindingSource.DataSource = this.servisniy_CentrDataSet;
            // 
            // pracivnukuBindingSource
            // 
            this.pracivnukuBindingSource.DataMember = "Pracivnuku";
            this.pracivnukuBindingSource.DataSource = this.servisniy_CentrDataSet;
            // 
            // dataGridViewTextBoxColumn35
            // 
            this.dataGridViewTextBoxColumn35.DataPropertyName = "ID_Tehnika";
            this.dataGridViewTextBoxColumn35.HeaderText = "ID_Tehnika";
            this.dataGridViewTextBoxColumn35.Name = "dataGridViewTextBoxColumn35";
            this.dataGridViewTextBoxColumn35.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn36
            // 
            this.dataGridViewTextBoxColumn36.DataPropertyName = "Model";
            this.dataGridViewTextBoxColumn36.HeaderText = "Model";
            this.dataGridViewTextBoxColumn36.Name = "dataGridViewTextBoxColumn36";
            // 
            // dataGridViewTextBoxColumn37
            // 
            this.dataGridViewTextBoxColumn37.DataPropertyName = "Data_Nachala";
            this.dataGridViewTextBoxColumn37.HeaderText = "Data_Nachala";
            this.dataGridViewTextBoxColumn37.Name = "dataGridViewTextBoxColumn37";
            // 
            // dataGridViewTextBoxColumn38
            // 
            this.dataGridViewTextBoxColumn38.DataPropertyName = "Data_Kontsa";
            this.dataGridViewTextBoxColumn38.HeaderText = "Data_Kontsa";
            this.dataGridViewTextBoxColumn38.Name = "dataGridViewTextBoxColumn38";
            // 
            // dataGridViewTextBoxColumn39
            // 
            this.dataGridViewTextBoxColumn39.DataPropertyName = "Status";
            this.dataGridViewTextBoxColumn39.HeaderText = "Status";
            this.dataGridViewTextBoxColumn39.Name = "dataGridViewTextBoxColumn39";
            // 
            // dataGridViewTextBoxColumn40
            // 
            this.dataGridViewTextBoxColumn40.DataPropertyName = "Tip";
            this.dataGridViewTextBoxColumn40.DataSource = this.tipBindingSource;
            this.dataGridViewTextBoxColumn40.DisplayMember = "Nazvanie";
            this.dataGridViewTextBoxColumn40.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.ComboBox;
            this.dataGridViewTextBoxColumn40.HeaderText = "Tip";
            this.dataGridViewTextBoxColumn40.Name = "dataGridViewTextBoxColumn40";
            this.dataGridViewTextBoxColumn40.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn40.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn40.ValueMember = "ID_Type";
            // 
            // tipBindingSource
            // 
            this.tipBindingSource.DataMember = "Tip";
            this.tipBindingSource.DataSource = this.servisniy_CentrDataSet;
            // 
            // dataGridViewTextBoxColumn41
            // 
            this.dataGridViewTextBoxColumn41.DataPropertyName = "Stan";
            this.dataGridViewTextBoxColumn41.DataSource = this.stanBindingSource;
            this.dataGridViewTextBoxColumn41.DisplayMember = "Nazvanie";
            this.dataGridViewTextBoxColumn41.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.ComboBox;
            this.dataGridViewTextBoxColumn41.HeaderText = "Stan";
            this.dataGridViewTextBoxColumn41.Name = "dataGridViewTextBoxColumn41";
            this.dataGridViewTextBoxColumn41.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn41.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn41.ValueMember = "ID_Stan";
            // 
            // stanBindingSource
            // 
            this.stanBindingSource.DataMember = "Stan";
            this.stanBindingSource.DataSource = this.servisniy_CentrDataSet;
            // 
            // dataGridViewTextBoxColumn44
            // 
            this.dataGridViewTextBoxColumn44.DataPropertyName = "ID_Stan";
            this.dataGridViewTextBoxColumn44.HeaderText = "ID_Stan";
            this.dataGridViewTextBoxColumn44.Name = "dataGridViewTextBoxColumn44";
            this.dataGridViewTextBoxColumn44.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn45
            // 
            this.dataGridViewTextBoxColumn45.DataPropertyName = "Nazvanie";
            this.dataGridViewTextBoxColumn45.HeaderText = "Nazvanie";
            this.dataGridViewTextBoxColumn45.Name = "dataGridViewTextBoxColumn45";
            // 
            // dataGridViewTextBoxColumn42
            // 
            this.dataGridViewTextBoxColumn42.DataPropertyName = "ID_Type";
            this.dataGridViewTextBoxColumn42.HeaderText = "ID_Type";
            this.dataGridViewTextBoxColumn42.Name = "dataGridViewTextBoxColumn42";
            this.dataGridViewTextBoxColumn42.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn43
            // 
            this.dataGridViewTextBoxColumn43.DataPropertyName = "Nazvanie";
            this.dataGridViewTextBoxColumn43.HeaderText = "Nazvanie";
            this.dataGridViewTextBoxColumn43.Name = "dataGridViewTextBoxColumn43";
            // 
            // postachBindingSource
            // 
            this.postachBindingSource.DataMember = "Postach";
            this.postachBindingSource.DataSource = this.servisniy_CentrDataSet;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "ID_Postach";
            this.dataGridViewTextBoxColumn1.HeaderText = "ID_Postach";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Nazvanie_Firmu";
            this.dataGridViewTextBoxColumn2.HeaderText = "Nazvanie_Firmu";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 200;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "FIO";
            this.dataGridViewTextBoxColumn3.HeaderText = "FIO";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 200;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Mobilniy";
            this.dataGridViewTextBoxColumn4.HeaderText = "Mobilniy";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Width = 150;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "E_mail";
            this.dataGridViewTextBoxColumn5.HeaderText = "E_mail";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Adress";
            this.dataGridViewTextBoxColumn6.HeaderText = "Adress";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "ID_Postavki";
            this.dataGridViewTextBoxColumn7.HeaderText = "ID_Postavki";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "Data";
            this.dataGridViewTextBoxColumn8.HeaderText = "Data";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "Price";
            this.dataGridViewTextBoxColumn9.HeaderText = "Price";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "Postach";
            this.dataGridViewTextBoxColumn10.DataSource = this.postachBindingSource;
            this.dataGridViewTextBoxColumn10.DisplayMember = "FIO";
            this.dataGridViewTextBoxColumn10.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.ComboBox;
            this.dataGridViewTextBoxColumn10.HeaderText = "Postach";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn10.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn10.ValueMember = "ID_Postach";
            this.dataGridViewTextBoxColumn10.Width = 200;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "Zapchastunu";
            this.dataGridViewTextBoxColumn11.DataSource = this.typeZapBindingSource;
            this.dataGridViewTextBoxColumn11.DisplayMember = "Nazvanie";
            this.dataGridViewTextBoxColumn11.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.ComboBox;
            this.dataGridViewTextBoxColumn11.HeaderText = "Zapchastunu";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn11.ValueMember = "ID_Type_Zap";
            this.dataGridViewTextBoxColumn11.Width = 170;
            // 
            // typeZapBindingSource
            // 
            this.typeZapBindingSource.DataMember = "Type_Zap";
            this.typeZapBindingSource.DataSource = this.servisniy_CentrDataSet;
            // 
            // postavkiBindingSource
            // 
            this.postavkiBindingSource.DataMember = "Postavki";
            this.postavkiBindingSource.DataSource = this.servisniy_CentrDataSet;
            // 
            // iDTypeZapDataGridViewTextBoxColumn
            // 
            this.iDTypeZapDataGridViewTextBoxColumn.DataPropertyName = "ID_Type_Zap";
            this.iDTypeZapDataGridViewTextBoxColumn.HeaderText = "ID_Type_Zap";
            this.iDTypeZapDataGridViewTextBoxColumn.Name = "iDTypeZapDataGridViewTextBoxColumn";
            this.iDTypeZapDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nazvanieDataGridViewTextBoxColumn
            // 
            this.nazvanieDataGridViewTextBoxColumn.DataPropertyName = "Nazvanie";
            this.nazvanieDataGridViewTextBoxColumn.HeaderText = "Nazvanie";
            this.nazvanieDataGridViewTextBoxColumn.Name = "nazvanieDataGridViewTextBoxColumn";
            this.nazvanieDataGridViewTextBoxColumn.Width = 150;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "ID_Zapchast";
            this.dataGridViewTextBoxColumn12.HeaderText = "ID_Zapchast";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "Model";
            this.dataGridViewTextBoxColumn13.HeaderText = "Model";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.Width = 150;
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "Price";
            this.dataGridViewTextBoxColumn14.HeaderText = "Price";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            // 
            // dataGridViewCheckBoxColumn1
            // 
            this.dataGridViewCheckBoxColumn1.DataPropertyName = "Na_Prodaj";
            this.dataGridViewCheckBoxColumn1.HeaderText = "Na_Prodaj";
            this.dataGridViewCheckBoxColumn1.Name = "dataGridViewCheckBoxColumn1";
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "Kilkist";
            this.dataGridViewTextBoxColumn15.HeaderText = "Kilkist";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.DataPropertyName = "Type_Zap";
            this.dataGridViewTextBoxColumn16.DataSource = this.typeZapBindingSource;
            this.dataGridViewTextBoxColumn16.DisplayMember = "Nazvanie";
            this.dataGridViewTextBoxColumn16.HeaderText = "Type_Zap";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            this.dataGridViewTextBoxColumn16.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn16.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn16.ValueMember = "ID_Type_Zap";
            this.dataGridViewTextBoxColumn16.Width = 150;
            // 
            // zapchastunuBindingSource
            // 
            this.zapchastunuBindingSource.DataMember = "Zapchastunu";
            this.zapchastunuBindingSource.DataSource = this.servisniy_CentrDataSet;
            // 
            // zdiysn_PoslugiBindingSource
            // 
            this.zdiysn_PoslugiBindingSource.DataMember = "Zdiysn_Poslugi";
            this.zdiysn_PoslugiBindingSource.DataSource = this.servisniy_CentrDataSet;
            // 
            // dataGridViewTextBoxColumn26
            // 
            this.dataGridViewTextBoxColumn26.DataPropertyName = "ID_ZdiysnPosl";
            this.dataGridViewTextBoxColumn26.HeaderText = "ID_ZdiysnPosl";
            this.dataGridViewTextBoxColumn26.Name = "dataGridViewTextBoxColumn26";
            this.dataGridViewTextBoxColumn26.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn27
            // 
            this.dataGridViewTextBoxColumn27.DataPropertyName = "Data";
            this.dataGridViewTextBoxColumn27.HeaderText = "Data";
            this.dataGridViewTextBoxColumn27.Name = "dataGridViewTextBoxColumn27";
            // 
            // dataGridViewTextBoxColumn28
            // 
            this.dataGridViewTextBoxColumn28.DataPropertyName = "Tehnika";
            this.dataGridViewTextBoxColumn28.HeaderText = "Tehnika";
            this.dataGridViewTextBoxColumn28.Name = "dataGridViewTextBoxColumn28";
            // 
            // dataGridViewTextBoxColumn29
            // 
            this.dataGridViewTextBoxColumn29.DataPropertyName = "Posluga";
            this.dataGridViewTextBoxColumn29.DataSource = this.poslugaBindingSource;
            this.dataGridViewTextBoxColumn29.DisplayMember = "Nazvanie";
            this.dataGridViewTextBoxColumn29.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.ComboBox;
            this.dataGridViewTextBoxColumn29.HeaderText = "Posluga";
            this.dataGridViewTextBoxColumn29.Name = "dataGridViewTextBoxColumn29";
            this.dataGridViewTextBoxColumn29.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn29.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn29.ValueMember = "ID_Posluga";
            this.dataGridViewTextBoxColumn29.Width = 210;
            // 
            // dataGridViewTextBoxColumn30
            // 
            this.dataGridViewTextBoxColumn30.DataPropertyName = "Pracivnuku";
            this.dataGridViewTextBoxColumn30.DataSource = this.pracivnukuBindingSource;
            this.dataGridViewTextBoxColumn30.DisplayMember = "Last_Name";
            this.dataGridViewTextBoxColumn30.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.ComboBox;
            this.dataGridViewTextBoxColumn30.HeaderText = "Pracivnuku";
            this.dataGridViewTextBoxColumn30.Name = "dataGridViewTextBoxColumn30";
            this.dataGridViewTextBoxColumn30.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn30.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn30.ValueMember = "ID_Pracik";
            // 
            // dataGridViewTextBoxColumn31
            // 
            this.dataGridViewTextBoxColumn31.DataPropertyName = "Zapchastunu";
            this.dataGridViewTextBoxColumn31.DataSource = this.typeZapBindingSource;
            this.dataGridViewTextBoxColumn31.DisplayMember = "Nazvanie";
            this.dataGridViewTextBoxColumn31.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.ComboBox;
            this.dataGridViewTextBoxColumn31.HeaderText = "Zapchastunu";
            this.dataGridViewTextBoxColumn31.Name = "dataGridViewTextBoxColumn31";
            this.dataGridViewTextBoxColumn31.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn31.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn31.ValueMember = "ID_Type_Zap";
            this.dataGridViewTextBoxColumn31.Width = 170;
            // 
            // dataGridViewTextBoxColumn32
            // 
            this.dataGridViewTextBoxColumn32.DataPropertyName = "ID_Posluga";
            this.dataGridViewTextBoxColumn32.HeaderText = "ID_Posluga";
            this.dataGridViewTextBoxColumn32.Name = "dataGridViewTextBoxColumn32";
            this.dataGridViewTextBoxColumn32.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn33
            // 
            this.dataGridViewTextBoxColumn33.DataPropertyName = "Nazvanie";
            this.dataGridViewTextBoxColumn33.HeaderText = "Nazvanie";
            this.dataGridViewTextBoxColumn33.Name = "dataGridViewTextBoxColumn33";
            this.dataGridViewTextBoxColumn33.Width = 250;
            // 
            // dataGridViewTextBoxColumn34
            // 
            this.dataGridViewTextBoxColumn34.DataPropertyName = "Price";
            this.dataGridViewTextBoxColumn34.HeaderText = "Price";
            this.dataGridViewTextBoxColumn34.Name = "dataGridViewTextBoxColumn34";
            // 
            // prodaj_ZapBindingSource
            // 
            this.prodaj_ZapBindingSource.DataMember = "Prodaj_Zap";
            this.prodaj_ZapBindingSource.DataSource = this.servisniy_CentrDataSet;
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.DataPropertyName = "ID_ProdajZap";
            this.dataGridViewTextBoxColumn19.HeaderText = "ID_ProdajZap";
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            this.dataGridViewTextBoxColumn19.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn20
            // 
            this.dataGridViewTextBoxColumn20.DataPropertyName = "Data";
            this.dataGridViewTextBoxColumn20.HeaderText = "Дата продажу";
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            this.dataGridViewTextBoxColumn20.Width = 105;
            // 
            // dataGridViewTextBoxColumn21
            // 
            this.dataGridViewTextBoxColumn21.DataPropertyName = "Price";
            this.dataGridViewTextBoxColumn21.HeaderText = "Ціна";
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            // 
            // dataGridViewTextBoxColumn22
            // 
            this.dataGridViewTextBoxColumn22.DataPropertyName = "Zapchastunu";
            this.dataGridViewTextBoxColumn22.DataSource = this.typeZapBindingSource;
            this.dataGridViewTextBoxColumn22.DisplayMember = "Nazvanie";
            this.dataGridViewTextBoxColumn22.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.ComboBox;
            this.dataGridViewTextBoxColumn22.HeaderText = "Запчастини";
            this.dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            this.dataGridViewTextBoxColumn22.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn22.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn22.ValueMember = "ID_Type_Zap";
            this.dataGridViewTextBoxColumn22.Width = 200;
            // 
            // prodaj_TehnBindingSource
            // 
            this.prodaj_TehnBindingSource.DataMember = "Prodaj_Tehn";
            this.prodaj_TehnBindingSource.DataSource = this.servisniy_CentrDataSet;
            // 
            // dataGridViewTextBoxColumn23
            // 
            this.dataGridViewTextBoxColumn23.DataPropertyName = "ID_ProdajTeh";
            this.dataGridViewTextBoxColumn23.Frozen = true;
            this.dataGridViewTextBoxColumn23.HeaderText = "ID_ProdajTeh";
            this.dataGridViewTextBoxColumn23.Name = "dataGridViewTextBoxColumn23";
            this.dataGridViewTextBoxColumn23.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn25
            // 
            this.dataGridViewTextBoxColumn25.DataPropertyName = "Tehnika";
            this.dataGridViewTextBoxColumn25.DataSource = this.tehnikaBindingSource;
            this.dataGridViewTextBoxColumn25.DisplayMember = "Model";
            this.dataGridViewTextBoxColumn25.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.ComboBox;
            this.dataGridViewTextBoxColumn25.HeaderText = "Техніка";
            this.dataGridViewTextBoxColumn25.Name = "dataGridViewTextBoxColumn25";
            this.dataGridViewTextBoxColumn25.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn25.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn25.ValueMember = "ID_Tehnika";
            this.dataGridViewTextBoxColumn25.Width = 150;
            // 
            // dataGridViewTextBoxColumn24
            // 
            this.dataGridViewTextBoxColumn24.DataPropertyName = "Price";
            this.dataGridViewTextBoxColumn24.HeaderText = "Ціна";
            this.dataGridViewTextBoxColumn24.Name = "dataGridViewTextBoxColumn24";
            // 
            // dataGridViewTextBoxColumn55
            // 
            this.dataGridViewTextBoxColumn55.DataPropertyName = "ID_Pracik";
            this.dataGridViewTextBoxColumn55.HeaderText = "ID_Pracik";
            this.dataGridViewTextBoxColumn55.Name = "dataGridViewTextBoxColumn55";
            this.dataGridViewTextBoxColumn55.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn56
            // 
            this.dataGridViewTextBoxColumn56.DataPropertyName = "Last_Name";
            this.dataGridViewTextBoxColumn56.HeaderText = "Last_Name";
            this.dataGridViewTextBoxColumn56.Name = "dataGridViewTextBoxColumn56";
            this.dataGridViewTextBoxColumn56.Width = 150;
            // 
            // dataGridViewTextBoxColumn57
            // 
            this.dataGridViewTextBoxColumn57.DataPropertyName = "Name";
            this.dataGridViewTextBoxColumn57.HeaderText = "Name";
            this.dataGridViewTextBoxColumn57.Name = "dataGridViewTextBoxColumn57";
            this.dataGridViewTextBoxColumn57.Width = 120;
            // 
            // dataGridViewTextBoxColumn58
            // 
            this.dataGridViewTextBoxColumn58.DataPropertyName = "Otchestvo";
            this.dataGridViewTextBoxColumn58.HeaderText = "Otchestvo";
            this.dataGridViewTextBoxColumn58.Name = "dataGridViewTextBoxColumn58";
            this.dataGridViewTextBoxColumn58.Width = 150;
            // 
            // dataGridViewTextBoxColumn59
            // 
            this.dataGridViewTextBoxColumn59.DataPropertyName = "Specialnost";
            this.dataGridViewTextBoxColumn59.HeaderText = "Specialnost";
            this.dataGridViewTextBoxColumn59.Name = "dataGridViewTextBoxColumn59";
            this.dataGridViewTextBoxColumn59.Width = 150;
            // 
            // postachBindingSource1
            // 
            this.postachBindingSource1.DataMember = "Postach";
            this.postachBindingSource1.DataSource = this.servisniy_CentrDataSet;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.Akt_peredachi_v_remontTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.PoslugaTableAdapter = null;
            this.tableAdapterManager.PostachTableAdapter = null;
            this.tableAdapterManager.PostavkiTableAdapter = null;
            this.tableAdapterManager.PracivnukuTableAdapter = null;
            this.tableAdapterManager.Prodaj_TehnTableAdapter = null;
            this.tableAdapterManager.Prodaj_ZapTableAdapter = null;
            this.tableAdapterManager.StanTableAdapter = null;
            this.tableAdapterManager.TehnikaTableAdapter = null;
            this.tableAdapterManager.TipTableAdapter = null;
            this.tableAdapterManager.Type_ZapTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = WindowsFormsApp2.Servisniy_CentrDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.ZapchastunuTableAdapter = this.zapchastunuTableAdapter;
            this.tableAdapterManager.Zdiysn_PoslugiTableAdapter = null;
            // 
            // zapchastunuTableAdapter
            // 
            this.zapchastunuTableAdapter.ClearBeforeFill = true;
            // 
            // servisniy_CentrDataSet1
            // 
            this.servisniy_CentrDataSet1.DataSetName = "Servisniy_CentrDataSet";
            this.servisniy_CentrDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // type_ZapTableAdapter
            // 
            this.type_ZapTableAdapter.ClearBeforeFill = true;
            // 
            // postachTableAdapter
            // 
            this.postachTableAdapter.ClearBeforeFill = true;
            // 
            // postavkiTableAdapter
            // 
            this.postavkiTableAdapter.ClearBeforeFill = true;
            // 
            // prodaj_ZapTableAdapter
            // 
            this.prodaj_ZapTableAdapter.ClearBeforeFill = true;
            // 
            // prodaj_TehnTableAdapter
            // 
            this.prodaj_TehnTableAdapter.ClearBeforeFill = true;
            // 
            // zdiysn_PoslugiTableAdapter
            // 
            this.zdiysn_PoslugiTableAdapter.ClearBeforeFill = true;
            // 
            // poslugaTableAdapter
            // 
            this.poslugaTableAdapter.ClearBeforeFill = true;
            // 
            // tehnikaTableAdapter
            // 
            this.tehnikaTableAdapter.ClearBeforeFill = true;
            // 
            // tipTableAdapter
            // 
            this.tipTableAdapter.ClearBeforeFill = true;
            // 
            // stanTableAdapter
            // 
            this.stanTableAdapter.ClearBeforeFill = true;
            // 
            // pracivnukuTableAdapter
            // 
            this.pracivnukuTableAdapter.ClearBeforeFill = true;
            // 
            // akt_peredachi_v_remontBindingSource
            // 
            this.akt_peredachi_v_remontBindingSource.DataMember = "Akt_peredachi_v_remont";
            this.akt_peredachi_v_remontBindingSource.DataSource = this.servisniy_CentrDataSet;
            // 
            // akt_peredachi_v_remontTableAdapter
            // 
            this.akt_peredachi_v_remontTableAdapter.ClearBeforeFill = true;
            // 
            // akt_peredachi_v_remontDataGridView
            // 
            this.akt_peredachi_v_remontDataGridView.AutoGenerateColumns = false;
            this.akt_peredachi_v_remontDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.akt_peredachi_v_remontDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn46,
            this.dataGridViewTextBoxColumn47,
            this.dataGridViewTextBoxColumn48,
            this.dataGridViewTextBoxColumn49,
            this.dataGridViewTextBoxColumn50,
            this.dataGridViewTextBoxColumn51,
            this.dataGridViewTextBoxColumn52,
            this.dataGridViewTextBoxColumn53,
            this.dataGridViewTextBoxColumn54});
            this.akt_peredachi_v_remontDataGridView.DataSource = this.akt_peredachi_v_remontBindingSource;
            this.akt_peredachi_v_remontDataGridView.Location = new System.Drawing.Point(6, 31);
            this.akt_peredachi_v_remontDataGridView.Name = "akt_peredachi_v_remontDataGridView";
            this.akt_peredachi_v_remontDataGridView.Size = new System.Drawing.Size(1206, 494);
            this.akt_peredachi_v_remontDataGridView.TabIndex = 4;
            // 
            // dataGridViewTextBoxColumn46
            // 
            this.dataGridViewTextBoxColumn46.DataPropertyName = "ID_Akt";
            this.dataGridViewTextBoxColumn46.HeaderText = "ID_Akt";
            this.dataGridViewTextBoxColumn46.Name = "dataGridViewTextBoxColumn46";
            this.dataGridViewTextBoxColumn46.ReadOnly = true;
            this.dataGridViewTextBoxColumn46.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // dataGridViewTextBoxColumn47
            // 
            this.dataGridViewTextBoxColumn47.DataPropertyName = "Data";
            this.dataGridViewTextBoxColumn47.HeaderText = "Data";
            this.dataGridViewTextBoxColumn47.Name = "dataGridViewTextBoxColumn47";
            // 
            // dataGridViewTextBoxColumn48
            // 
            this.dataGridViewTextBoxColumn48.DataPropertyName = "Last_Name";
            this.dataGridViewTextBoxColumn48.HeaderText = "Last_Name";
            this.dataGridViewTextBoxColumn48.Name = "dataGridViewTextBoxColumn48";
            // 
            // dataGridViewTextBoxColumn49
            // 
            this.dataGridViewTextBoxColumn49.DataPropertyName = "Name";
            this.dataGridViewTextBoxColumn49.HeaderText = "Name";
            this.dataGridViewTextBoxColumn49.Name = "dataGridViewTextBoxColumn49";
            // 
            // dataGridViewTextBoxColumn50
            // 
            this.dataGridViewTextBoxColumn50.DataPropertyName = "Otchestvo";
            this.dataGridViewTextBoxColumn50.HeaderText = "Otchestvo";
            this.dataGridViewTextBoxColumn50.Name = "dataGridViewTextBoxColumn50";
            // 
            // dataGridViewTextBoxColumn51
            // 
            this.dataGridViewTextBoxColumn51.DataPropertyName = "Mobilniy";
            this.dataGridViewTextBoxColumn51.HeaderText = "Mobilniy";
            this.dataGridViewTextBoxColumn51.Name = "dataGridViewTextBoxColumn51";
            // 
            // dataGridViewTextBoxColumn52
            // 
            this.dataGridViewTextBoxColumn52.DataPropertyName = "Tehnika";
            this.dataGridViewTextBoxColumn52.DataSource = this.tehnikaBindingSource;
            this.dataGridViewTextBoxColumn52.DisplayMember = "Model";
            this.dataGridViewTextBoxColumn52.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.ComboBox;
            this.dataGridViewTextBoxColumn52.HeaderText = "Tehnika";
            this.dataGridViewTextBoxColumn52.Name = "dataGridViewTextBoxColumn52";
            this.dataGridViewTextBoxColumn52.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn52.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn52.ValueMember = "ID_Tehnika";
            // 
            // dataGridViewTextBoxColumn53
            // 
            this.dataGridViewTextBoxColumn53.DataPropertyName = "Posluga";
            this.dataGridViewTextBoxColumn53.DataSource = this.poslugaBindingSource;
            this.dataGridViewTextBoxColumn53.DisplayMember = "Nazvanie";
            this.dataGridViewTextBoxColumn53.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.ComboBox;
            this.dataGridViewTextBoxColumn53.HeaderText = "Posluga";
            this.dataGridViewTextBoxColumn53.Name = "dataGridViewTextBoxColumn53";
            this.dataGridViewTextBoxColumn53.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn53.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn53.ValueMember = "ID_Posluga";
            // 
            // dataGridViewTextBoxColumn54
            // 
            this.dataGridViewTextBoxColumn54.DataPropertyName = "Pracivnuku";
            this.dataGridViewTextBoxColumn54.DataSource = this.pracivnukuBindingSource;
            this.dataGridViewTextBoxColumn54.DisplayMember = "Last_Name";
            this.dataGridViewTextBoxColumn54.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.ComboBox;
            this.dataGridViewTextBoxColumn54.HeaderText = "Pracivnuku";
            this.dataGridViewTextBoxColumn54.Name = "dataGridViewTextBoxColumn54";
            this.dataGridViewTextBoxColumn54.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn54.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn54.ValueMember = "ID_Pracik";
            this.dataGridViewTextBoxColumn54.Width = 250;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1264, 762);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.tabControl6);
            this.Controls.Add(this.tabControl5);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.tabControl2);
            this.Controls.Add(this.tabControl4);
            this.Controls.Add(this.tabControl3);
            this.Controls.Add(this.tabControl7);
            this.MainMenuStrip = this.menuStrip1;
            this.MaximumSize = new System.Drawing.Size(1680, 1050);
            this.MinimumSize = new System.Drawing.Size(1280, 800);
            this.Name = "Form1";
            this.Text = "Сервісний центр";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator1)).EndInit();
            this.bindingNavigator1.ResumeLayout(false);
            this.bindingNavigator1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.postachDataGridView)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.postavkiDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator2)).EndInit();
            this.bindingNavigator2.ResumeLayout(false);
            this.bindingNavigator2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.zapchastunuDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator3)).EndInit();
            this.bindingNavigator3.ResumeLayout(false);
            this.bindingNavigator3.PerformLayout();
            this.tabControl2.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator4)).EndInit();
            this.bindingNavigator4.ResumeLayout(false);
            this.bindingNavigator4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.type_ZapDataGridView)).EndInit();
            this.tabControl3.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator5)).EndInit();
            this.bindingNavigator5.ResumeLayout(false);
            this.bindingNavigator5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.prodaj_ZapDataGridView)).EndInit();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator6)).EndInit();
            this.bindingNavigator6.ResumeLayout(false);
            this.bindingNavigator6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.prodaj_TehnDataGridView)).EndInit();
            this.tabControl4.ResumeLayout(false);
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator7)).EndInit();
            this.bindingNavigator7.ResumeLayout(false);
            this.bindingNavigator7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.zdiysn_PoslugiDataGridView)).EndInit();
            this.tabPage8.ResumeLayout(false);
            this.tabPage8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.poslugaDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator8)).EndInit();
            this.bindingNavigator8.ResumeLayout(false);
            this.bindingNavigator8.PerformLayout();
            this.tabControl5.ResumeLayout(false);
            this.tabPage9.ResumeLayout(false);
            this.tabPage9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator9)).EndInit();
            this.bindingNavigator9.ResumeLayout(false);
            this.bindingNavigator9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tehnikaDataGridView)).EndInit();
            this.tabPage11.ResumeLayout(false);
            this.tabPage11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator11)).EndInit();
            this.bindingNavigator11.ResumeLayout(false);
            this.bindingNavigator11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stanDataGridView)).EndInit();
            this.tabPage10.ResumeLayout(false);
            this.tabPage10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator10)).EndInit();
            this.bindingNavigator10.ResumeLayout(false);
            this.bindingNavigator10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tipDataGridView)).EndInit();
            this.tabPage12.ResumeLayout(false);
            this.tabPage12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator12)).EndInit();
            this.bindingNavigator12.ResumeLayout(false);
            this.bindingNavigator12.PerformLayout();
            this.tabControl6.ResumeLayout(false);
            this.tabControl7.ResumeLayout(false);
            this.tabPage13.ResumeLayout(false);
            this.tabPage13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator13)).EndInit();
            this.bindingNavigator13.ResumeLayout(false);
            this.bindingNavigator13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pracivnukuDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.servisniy_CentrDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tehnikaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.poslugaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pracivnukuBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tipBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stanBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.postachBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.typeZapBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.postavkiBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zapchastunuBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zdiysn_PoslugiBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prodaj_ZapBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prodaj_TehnBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.postachBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.servisniy_CentrDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.akt_peredachi_v_remontBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.akt_peredachi_v_remontDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem роботаЗДанимиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem категоріїToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem постачальникиПоставкиToolStripMenuItem;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private Servisniy_CentrDataSet servisniy_CentrDataSet;
        private System.Windows.Forms.BindingSource postachBindingSource;
        private Servisniy_CentrDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator bindingNavigator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.BindingSource postavkiBindingSource;
        private System.Windows.Forms.BindingNavigator bindingNavigator2;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton toolStripButton6;
        private System.Windows.Forms.ToolStripButton toolStripButton7;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton toolStripButton8;
        private Servisniy_CentrDataSetTableAdapters.ZapchastunuTableAdapter zapchastunuTableAdapter;
        private System.Windows.Forms.BindingSource zapchastunuBindingSource;
        private System.Windows.Forms.BindingSource postachBindingSource1;
        private System.Windows.Forms.ToolStripMenuItem запчастиниToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem продажToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem технікаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem послугиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem оформленняПослугиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem списокПрацівниківToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem звітиToolStripMenuItem;
        private Servisniy_CentrDataSet servisniy_CentrDataSet1;
        private System.Windows.Forms.BindingSource typeZapBindingSource;
        private Servisniy_CentrDataSetTableAdapters.Type_ZapTableAdapter type_ZapTableAdapter;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.DataGridView postachDataGridView;
        private System.Windows.Forms.DataGridView postavkiDataGridView;
        private Servisniy_CentrDataSetTableAdapters.PostachTableAdapter postachTableAdapter;
        private Servisniy_CentrDataSetTableAdapters.PostavkiTableAdapter postavkiTableAdapter;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView zapchastunuDataGridView;
        private System.Windows.Forms.BindingNavigator bindingNavigator3;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem1;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem1;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator3;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem1;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator4;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem1;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator5;
        private System.Windows.Forms.ToolStripButton toolStripButton9;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.BindingNavigator bindingNavigator4;
        private System.Windows.Forms.ToolStripButton toolStripButton17;
        private System.Windows.Forms.ToolStripLabel toolStripLabel3;
        private System.Windows.Forms.ToolStripButton toolStripButton18;
        private System.Windows.Forms.ToolStripButton toolStripButton19;
        private System.Windows.Forms.ToolStripButton toolStripButton20;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripButton toolStripButton21;
        private System.Windows.Forms.ToolStripButton toolStripButton22;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
        private System.Windows.Forms.ToolStripButton toolStripButton23;
        private System.Windows.Forms.DataGridView type_ZapDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.ToolStripButton toolStripButton12;
        private System.Windows.Forms.ToolStripButton toolStripButton13;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox2;
        private System.Windows.Forms.ToolStripLabel toolStripLabel2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripButton toolStripButton14;
        private System.Windows.Forms.ToolStripButton toolStripButton15;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripButton toolStripButton10;
        private System.Windows.Forms.ToolStripButton toolStripButton11;
        private System.Windows.Forms.ToolStripButton toolStripButton16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDTypeZapDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nazvanieDataGridViewTextBoxColumn;
        private System.Windows.Forms.TabControl tabControl3;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.BindingSource prodaj_ZapBindingSource;
        private Servisniy_CentrDataSetTableAdapters.Prodaj_ZapTableAdapter prodaj_ZapTableAdapter;
        private System.Windows.Forms.BindingNavigator bindingNavigator5;
        private System.Windows.Forms.ToolStripButton toolStripButton24;
        private System.Windows.Forms.ToolStripLabel toolStripLabel4;
        private System.Windows.Forms.ToolStripButton toolStripButton25;
        private System.Windows.Forms.ToolStripButton toolStripButton26;
        private System.Windows.Forms.ToolStripButton toolStripButton27;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator10;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator11;
        private System.Windows.Forms.ToolStripButton toolStripButton28;
        private System.Windows.Forms.ToolStripButton toolStripButton29;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator12;
        private System.Windows.Forms.ToolStripButton toolStripButton30;
        private System.Windows.Forms.DataGridView prodaj_ZapDataGridView;
        private System.Windows.Forms.BindingSource prodaj_TehnBindingSource;
        private Servisniy_CentrDataSetTableAdapters.Prodaj_TehnTableAdapter prodaj_TehnTableAdapter;
        private System.Windows.Forms.DataGridView prodaj_TehnDataGridView;
        private System.Windows.Forms.BindingNavigator bindingNavigator6;
        private System.Windows.Forms.ToolStripButton toolStripButton31;
        private System.Windows.Forms.ToolStripLabel toolStripLabel5;
        private System.Windows.Forms.ToolStripButton toolStripButton32;
        private System.Windows.Forms.ToolStripButton toolStripButton33;
        private System.Windows.Forms.ToolStripButton toolStripButton34;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator13;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox5;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator14;
        private System.Windows.Forms.ToolStripButton toolStripButton35;
        private System.Windows.Forms.ToolStripButton toolStripButton36;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator15;
        private System.Windows.Forms.ToolStripButton toolStripButton37;
        private System.Windows.Forms.TabControl tabControl4;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.BindingSource zdiysn_PoslugiBindingSource;
        private Servisniy_CentrDataSetTableAdapters.Zdiysn_PoslugiTableAdapter zdiysn_PoslugiTableAdapter;
        private System.Windows.Forms.BindingNavigator bindingNavigator7;
        private System.Windows.Forms.ToolStripButton toolStripButton38;
        private System.Windows.Forms.ToolStripLabel toolStripLabel6;
        private System.Windows.Forms.ToolStripButton toolStripButton39;
        private System.Windows.Forms.ToolStripButton toolStripButton40;
        private System.Windows.Forms.ToolStripButton toolStripButton41;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator16;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox6;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator17;
        private System.Windows.Forms.ToolStripButton toolStripButton42;
        private System.Windows.Forms.ToolStripButton toolStripButton43;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator18;
        private System.Windows.Forms.ToolStripButton toolStripButton44;
        private System.Windows.Forms.DataGridView zdiysn_PoslugiDataGridView;
        private System.Windows.Forms.BindingNavigator bindingNavigator8;
        private System.Windows.Forms.ToolStripButton toolStripButton45;
        private System.Windows.Forms.ToolStripLabel toolStripLabel7;
        private System.Windows.Forms.ToolStripButton toolStripButton46;
        private System.Windows.Forms.ToolStripButton toolStripButton47;
        private System.Windows.Forms.ToolStripButton toolStripButton48;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator19;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox7;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator20;
        private System.Windows.Forms.ToolStripButton toolStripButton49;
        private System.Windows.Forms.ToolStripButton toolStripButton50;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator21;
        private System.Windows.Forms.ToolStripButton toolStripButton51;
        private System.Windows.Forms.BindingSource poslugaBindingSource;
        private Servisniy_CentrDataSetTableAdapters.PoslugaTableAdapter poslugaTableAdapter;
        private System.Windows.Forms.DataGridView poslugaDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn32;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn33;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn34;
        private System.Windows.Forms.TabControl tabControl5;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.TabPage tabPage10;
        private System.Windows.Forms.TabPage tabPage11;
        private System.Windows.Forms.BindingSource tehnikaBindingSource;
        private Servisniy_CentrDataSetTableAdapters.TehnikaTableAdapter tehnikaTableAdapter;
        private System.Windows.Forms.DataGridView tehnikaDataGridView;
        private System.Windows.Forms.BindingSource tipBindingSource;
        private Servisniy_CentrDataSetTableAdapters.TipTableAdapter tipTableAdapter;
        private System.Windows.Forms.DataGridView tipDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn42;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn43;
        private System.Windows.Forms.BindingSource stanBindingSource;
        private Servisniy_CentrDataSetTableAdapters.StanTableAdapter stanTableAdapter;
        private System.Windows.Forms.DataGridView stanDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn44;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn45;
        private System.Windows.Forms.BindingNavigator bindingNavigator9;
        private System.Windows.Forms.ToolStripButton toolStripButton52;
        private System.Windows.Forms.ToolStripLabel toolStripLabel8;
        private System.Windows.Forms.ToolStripButton toolStripButton53;
        private System.Windows.Forms.ToolStripButton toolStripButton54;
        private System.Windows.Forms.ToolStripButton toolStripButton55;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator22;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox8;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator23;
        private System.Windows.Forms.ToolStripButton toolStripButton56;
        private System.Windows.Forms.ToolStripButton toolStripButton57;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator24;
        private System.Windows.Forms.ToolStripButton toolStripButton58;
        private System.Windows.Forms.BindingNavigator bindingNavigator11;
        private System.Windows.Forms.ToolStripButton toolStripButton66;
        private System.Windows.Forms.ToolStripLabel toolStripLabel10;
        private System.Windows.Forms.ToolStripButton toolStripButton67;
        private System.Windows.Forms.ToolStripButton toolStripButton68;
        private System.Windows.Forms.ToolStripButton toolStripButton69;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator28;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox10;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator29;
        private System.Windows.Forms.ToolStripButton toolStripButton70;
        private System.Windows.Forms.ToolStripButton toolStripButton71;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator30;
        private System.Windows.Forms.ToolStripButton toolStripButton72;
        private System.Windows.Forms.BindingNavigator bindingNavigator10;
        private System.Windows.Forms.ToolStripButton toolStripButton59;
        private System.Windows.Forms.ToolStripLabel toolStripLabel9;
        private System.Windows.Forms.ToolStripButton toolStripButton60;
        private System.Windows.Forms.ToolStripButton toolStripButton61;
        private System.Windows.Forms.ToolStripButton toolStripButton62;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator25;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox9;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator26;
        private System.Windows.Forms.ToolStripButton toolStripButton63;
        private System.Windows.Forms.ToolStripButton toolStripButton64;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator27;
        private System.Windows.Forms.ToolStripButton toolStripButton65;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn35;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn36;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn37;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn38;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn39;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn40;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn41;
        private System.Windows.Forms.TabPage tabPage12;
        private System.Windows.Forms.TabControl tabControl6;
        private System.Windows.Forms.BindingNavigator bindingNavigator12;
        private System.Windows.Forms.ToolStripButton toolStripButton73;
        private System.Windows.Forms.ToolStripLabel toolStripLabel11;
        private System.Windows.Forms.ToolStripButton toolStripButton74;
        private System.Windows.Forms.ToolStripButton toolStripButton75;
        private System.Windows.Forms.ToolStripButton toolStripButton76;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator31;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox11;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator32;
        private System.Windows.Forms.ToolStripButton toolStripButton77;
        private System.Windows.Forms.ToolStripButton toolStripButton78;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator33;
        private System.Windows.Forms.ToolStripButton toolStripButton79;
        private System.Windows.Forms.TabControl tabControl7;
        private System.Windows.Forms.TabPage tabPage13;
        private System.Windows.Forms.BindingSource pracivnukuBindingSource;
        private Servisniy_CentrDataSetTableAdapters.PracivnukuTableAdapter pracivnukuTableAdapter;
        private System.Windows.Forms.BindingNavigator bindingNavigator13;
        private System.Windows.Forms.ToolStripButton toolStripButton80;
        private System.Windows.Forms.ToolStripLabel toolStripLabel12;
        private System.Windows.Forms.ToolStripButton toolStripButton81;
        private System.Windows.Forms.ToolStripButton toolStripButton82;
        private System.Windows.Forms.ToolStripButton toolStripButton83;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator34;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox12;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator35;
        private System.Windows.Forms.ToolStripButton toolStripButton84;
        private System.Windows.Forms.ToolStripButton toolStripButton85;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator36;
        private System.Windows.Forms.ToolStripButton toolStripButton86;
        private System.Windows.Forms.DataGridView pracivnukuDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn55;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn56;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn57;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn58;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn59;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn22;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn26;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn27;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn28;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn29;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn30;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn31;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn23;
        private System.Windows.Forms.DataGridViewTextBoxColumn Date_Z;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn25;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn24;
        private System.Windows.Forms.DataGridViewTextBoxColumn comments;
        private System.Windows.Forms.BindingSource akt_peredachi_v_remontBindingSource;
        private Servisniy_CentrDataSetTableAdapters.Akt_peredachi_v_remontTableAdapter akt_peredachi_v_remontTableAdapter;
        private System.Windows.Forms.DataGridView akt_peredachi_v_remontDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn46;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn47;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn48;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn49;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn50;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn51;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn52;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn53;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn54;
    }
}

